# Fleet Admin

Web admin for the Uber-clone API. Vite 5, Bootstrap 5.3 and plain JavaScript (ES modules), no framework.

## Features
- Dashboard: riders, drivers, live rides, today's trips, 7-day chart, recent account actions.
- Riders and Drivers directories: search (name, email, phone, plate, ID), filter by standing and driver status, sort, paging. Filters live in the URL.
- Person detail: profile, activity stats, current ride, recent rides, vehicle and last location, full account history.
- Moderation: **Suspend** (indefinite or timed), **Ban**, **Reinstate**, each with a required reason. An in-progress trip asks for explicit confirmation (`force`).
- Rides: live/completed/cancelled tabs, search, per-user filter. Ride detail shows route, fare, timeline, driver offers and payment.
- System: queue counts, housekeeping jobs with "Run now", run history.
- Light and dark theme, responsive down to phone width.

## Run
Requires the API with the moderation patch applied (migration `0002_moderation`) and an admin user (`bun run seed`).

```bash
cd web-admin
npm install
cp .env.example .env     # optional
npm run dev              # http://localhost:5173
```

The dev and preview servers proxy `/api` to `API_PROXY_TARGET` (default `http://localhost:3000`), so no CORS setup is needed.

Production: `npm run build`, then serve `dist/` behind the same origin as the API (reverse-proxy `/api`). If it is hosted elsewhere, set `VITE_API_URL=https://api.example.com/api/v1` at build time and allow that origin in the API's `CORS_ORIGIN`.

## Auth notes
- Only users with role `admin` can sign in; others are signed out straight away.
- The access token is kept in memory. The refresh token is kept in `sessionStorage`, so a reload keeps you signed in but closing the tab does not.
- Refresh tokens are single-use on the server, so the client refreshes through a single in-flight request.

## Layout
`src/lib` (api, auth, router, dom, format), `src/components` (layout, modal, toast, pager, ui bits), `src/pages` (one file per screen), `src/styles/app.css`.
