import { api } from "../lib/api.js";
import { html, mount, on } from "../lib/dom.js";
import { coords, date, dateTime, mapUrl, money, num, pct, plural, relTime, shortId } from "../lib/format.js";
import { setSection } from "../components/layout.js";
import { openModeration } from "../components/moderation.js";
import { toast } from "../components/toast.js";
import { avatar, driverState, errorBox, moderationButtons, plate, rating, rideState, roleTag, skeletonPanel, standing } from "../components/ui.js";

const MOD_TEXT = {
  suspend: ["Suspended", "s-hold"],
  ban: ["Banned", "s-stop"],
  reinstate: ["Reinstated", "s-go"],
  auto_reinstate: ["Reinstated automatically", "s-go"],
};

const routeLines = (r) => html`<div class="route-cell">
  <div><i class="bi bi-record-circle"></i><span class="truncate">${r.pickup.address ?? coords(r.pickup.lat, r.pickup.lng)}</span></div>
  <div><i class="bi bi-geo-alt-fill"></i><span class="truncate">${r.dropoff.address ?? coords(r.dropoff.lat, r.dropoff.lng)}</span></div>
</div>`;

function restriction(d) {
  const { status, reason, until, changedAt, changedBy } = d.user.account;
  if (status === "active") return "";
  const cls = status === "banned" ? "s-stop" : "s-hold";
  const what = status === "banned" ? "This account is banned" : until ? `This account is suspended until ${dateTime(until)}` : "This account is suspended";
  return html`<div class="restriction ${cls}" role="status">
    <div>
      <div class="what">${what}</div>
      ${reason ? html`<div>${reason}</div>` : ""}
      <div class="cell-sub">${changedBy ? html`Set by ${changedBy.name}` : "Set automatically"}${changedAt ? html` ${relTime(changedAt)}` : ""}</div>
    </div>
    <button type="button" class="btn btn-success btn-sm" data-mod="reinstate"><i class="bi bi-arrow-counterclockwise me-1"></i>Reinstate</button>
  </div>`;
}

function stats(d) {
  const { stats: s, user } = d;
  const isDriver = user.role === "driver";
  const cell = (v, l) => html`<div><div class="v">${v}</div><div class="l">${l}</div></div>`;
  return html`<div class="panel">
    <div class="panel-head"><h2>Activity</h2><a class="small" href="#/rides?userId=${user.id}">View all rides</a></div>
    <div class="stat-grid">
      ${cell(num(s.completed), "Trips completed")}
      ${cell(pct(s.cancelled, s.totalRides), `Cancelled (${num(s.cancelled)} of ${num(s.totalRides)})`)}
      ${isDriver ? cell(money(s.earnings), "Earned") : cell(money(s.gross), "Spent")}
      ${isDriver ? cell(num(s.cancelledByDriver), "Cancelled after accepting") : cell(num(s.cancelledByRider), "Cancelled by rider")}
      ${isDriver
        ? cell(s.offers.total ? pct(s.offers.accepted, s.offers.total) : "-", `Offers accepted (${num(s.offers.accepted)} of ${num(s.offers.total)})`)
        : cell(num(s.noDrivers), "No driver found")}
      ${isDriver ? cell(num(s.offers.declined + s.offers.expired), "Offers declined or missed") : cell(s.lastRideAt ? relTime(s.lastRideAt) : "Never", "Last ride requested")}
    </div>
  </div>`;
}

function currentRide(d) {
  const r = d.activeRide;
  if (!r) return "";
  return html`<div class="panel mt-3">
    <div class="panel-head"><h2>Current ride</h2>${rideState(r.status)}</div>
    <div class="panel-body d-flex flex-wrap align-items-center justify-content-between gap-3">
      ${routeLines(r)}
      <div class="text-end"><div class="num fs-5">${money(r.fare, r.currency)}</div><a href="#/rides/${r.id}" class="small">Open ride</a></div>
    </div>
  </div>`;
}

function recentRides(d) {
  const rows = d.recentRides;
  const isDriver = d.user.role === "driver";
  return html`<div class="panel mt-3">
    <div class="panel-head"><h2>Recent rides</h2></div>
    ${rows.length
      ? html`<div class="table-responsive"><table class="table table-hover">
          <thead><tr><th scope="col">Status</th><th scope="col">Route</th><th scope="col">${isDriver ? "Rider" : "Driver"}</th><th scope="col">Fare</th><th scope="col">Requested</th></tr></thead>
          <tbody>${rows.map((r) => {
            const other = isDriver ? r.rider : r.driver;
            return html`<tr class="clickable" data-ride="${r.id}">
              <td>${rideState(r.status)}</td>
              <td>${routeLines(r)}</td>
              <td>${other ? html`<a href="#/users/${other.id}" class="text-reset">${other.name}</a>` : html`<span class="text-body-secondary">Unassigned</span>`}</td>
              <td class="num">${money(r.fare, r.currency)}${r.isFinalFare ? "" : html` <span class="cell-sub">est.</span>`}</td>
              <td title="${dateTime(r.requestedAt)}">${relTime(r.requestedAt)}</td>
            </tr>`;
          })}</tbody>
        </table></div>`
      : html`<div class="panel-body text-body-secondary">No rides yet.</div>`}
  </div>`;
}

function history(d) {
  return html`<div class="panel mt-3">
    <div class="panel-head"><h2>Account history</h2></div>
    <div class="panel-body">
      ${d.moderation.length
        ? html`<ul class="timeline">${d.moderation.map((m) => {
            const [label, cls] = MOD_TEXT[m.action] ?? [m.action, "s-idle"];
            const affected = m.affectedRides.length;
            return html`<li class="${cls}">
              <span class="lamp"></span>
              <div><span class="fw-semibold">${label}</span>${m.admin ? html` by ${m.admin.name}` : ""}${m.until ? html` until ${dateTime(m.until)}` : ""}</div>
              ${m.reason ? html`<div class="quote">${m.reason}</div>` : ""}
              ${affected ? html`<div class="cell-sub">${plural(affected, "ride")} affected</div>` : ""}
              <div class="when" title="${dateTime(m.createdAt)}">${relTime(m.createdAt)}</div>
            </li>`;
          })}</ul>`
        : html`<div class="text-body-secondary">This account has never been suspended or banned.</div>`}
    </div>
  </div>`;
}

function profile(d) {
  const u = d.user;
  return html`<div class="panel">
    <div class="panel-head"><h2>Profile</h2></div>
    <div class="panel-body"><dl class="kv">
      <dt>Email</dt><dd>${u.email}</dd>
      <dt>Phone</dt><dd>${u.phone ?? html`<span class="text-body-secondary">None</span>`}</dd>
      <dt>Rating</dt><dd>${rating(u.rating)}</dd>
      <dt>Joined</dt><dd title="${dateTime(u.createdAt)}">${date(u.createdAt)}</dd>
      <dt>Last sign-in</dt><dd title="${u.lastLoginAt ? dateTime(u.lastLoginAt) : ""}">${relTime(u.lastLoginAt)}</dd>
      <dt>Signed in on</dt><dd>${plural(d.activeSessions, "device")}</dd>
      ${u.isActive ? "" : html`<dt>Login</dt><dd><span class="state s-stop"><span class="lamp"></span>Disabled</span></dd>`}
      <dt>User ID</dt><dd><span title="${u.id}">${shortId(u.id)}</span> <button type="button" class="btn btn-link btn-sm p-0 ms-1" data-copy="${u.id}">Copy</button></dd>
    </dl></div>
  </div>`;
}

function vehicle(d) {
  const v = d.driver;
  if (!v) return html`<div class="panel mt-3"><div class="panel-head"><h2>Vehicle</h2></div><div class="panel-body text-body-secondary">This driver hasn't added a vehicle yet.</div></div>`;
  const loc = v.location;
  return html`<div class="panel mt-3">
    <div class="panel-head"><h2>Vehicle and location</h2>${driverState(v.status)}</div>
    <div class="panel-body"><dl class="kv">
      <dt>Plate</dt><dd>${plate(v.vehicle.plate)}</dd>
      <dt>Vehicle</dt><dd>${v.vehicle.color} ${v.vehicle.make} ${v.vehicle.model}</dd>
      <dt>Class</dt><dd class="text-capitalize">${v.vehicle.type}</dd>
      <dt>Licence</dt><dd>${v.licenseNumber}</dd>
      <dt>Last location</dt>
      <dd>${loc
        ? html`${coords(loc.lat, loc.lng)}<div class="cell-sub">${loc.at ? `Updated ${relTime(loc.at)}` : "Time unknown"}</div><a href="${mapUrl(loc.lat, loc.lng)}" target="_blank" rel="noopener noreferrer" class="small">Open in OpenStreetMap</a>`
        : html`<span class="text-body-secondary">No location yet</span>`}</dd>
    </dl></div>
  </div>`;
}

export function userDetailPage(outlet, ctx) {
  const id = ctx.params.id;
  let disposed = false;
  let data = null;

  mount(outlet, html`<div class="panel">${skeletonPanel(6)}</div>`);

  async function load() {
    try {
      data = await api.get(`/admin/users/${id}`);
      if (disposed) return;
      render();
    } catch (e) {
      if (disposed) return;
      if (e.status === 404) {
        mount(outlet, html`<div class="panel"><div class="empty-state"><i class="bi bi-person-x"></i><div class="h5 m-0">Person not found</div><div class="text-body-secondary">They may have been removed, or the link is wrong.</div><a class="btn btn-primary" href="#/drivers">Back to drivers</a></div></div>`);
      } else {
        mount(outlet, html`<div class="panel">${errorBox(e)}</div>`);
      }
    }
  }

  function render() {
    const d = data;
    const u = d.user;
    setSection(u.role === "driver" ? "drivers" : "riders");
    mount(
      outlet,
      html`<nav aria-label="Breadcrumb" class="mb-2 small"><a href="#/${u.role}s" class="text-body-secondary">${u.role === "driver" ? "Drivers" : "Riders"}</a></nav>
        <div class="page-head">
          <div class="d-flex align-items-center gap-3 min-w-0">
            ${avatar(u.fullName, true)}
            <div class="min-w-0">
              <h1 class="truncate">${u.fullName}</h1>
              <div class="d-flex flex-wrap align-items-center gap-2 mt-1">${roleTag(u.role)}${standing(u.account)}${d.driver ? driverState(d.driver.status) : ""}</div>
            </div>
          </div>
          <div class="d-flex flex-wrap gap-2" id="actions">
            <button type="button" class="btn btn-outline-secondary" id="reload" aria-label="Refresh"><i class="bi bi-arrow-clockwise"></i></button>
            ${moderationButtons(u.account.status)}
          </div>
        </div>
        ${restriction(d)}
        <div class="row g-3">
          <div class="col-lg-8">${stats(d)}${currentRide(d)}${recentRides(d)}${history(d)}</div>
          <div class="col-lg-4">${profile(d)}${u.role === "driver" ? vehicle(d) : ""}</div>
        </div>`,
    );
  }

  const offs = [
    on(outlet, "click", "[data-mod]", (_e, btn) => {
      if (data) openModeration({ action: btn.getAttribute("data-mod"), user: { ...data.user }, onDone: load });
    }),
    on(outlet, "click", "#reload", load),
    on(outlet, "click", "[data-retry]", load),
    on(outlet, "click", "tr[data-ride]", (e, tr) => {
      if (e.target.closest("a")) return;
      window.location.hash = `#/rides/${tr.getAttribute("data-ride")}`;
    }),
    on(outlet, "click", "[data-copy]", async (_e, btn) => {
      try {
        await navigator.clipboard.writeText(btn.getAttribute("data-copy"));
        toast("User ID copied.", "info");
      } catch {
        toast("Couldn't copy. Select the ID from the API instead.", "warning");
      }
    }),
  ];

  load();
  return {
    unmount() {
      disposed = true;
      offs.forEach((off) => off());
    },
  };
}
