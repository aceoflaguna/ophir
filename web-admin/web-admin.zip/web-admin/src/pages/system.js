import { api } from "../lib/api.js";
import { autoRefresh, html, mount, on } from "../lib/dom.js";
import { dateTime, num, relTime, titleCase } from "../lib/format.js";
import { toast } from "../components/toast.js";
import { errorBox, skeletonPanel, state } from "../components/ui.js";

const JOBS = [
  ["purge-refresh-tokens", "Purge refresh tokens", "Deletes expired and revoked sign-in tokens."],
  ["expire-stale-offers", "Expire stale offers", "Closes driver offers nobody answered in time."],
  ["expire-stale-searches", "Expire stale searches", "Gives up on rides that searched too long."],
  ["release-stuck-rides", "Release stuck rides", "Frees drivers tied to rides that went quiet."],
  ["offline-stale-drivers", "Offline stale drivers", "Takes drivers offline when their app stops reporting."],
  ["lift-expired-suspensions", "Lift expired suspensions", "Reinstates accounts whose suspension has ended."],
  ["purge-housekeeping-runs", "Purge job history", "Trims old entries from the run log below."],
];
const COUNTS = [["active", "Running", "s-route"], ["waiting", "Waiting", "s-hold"], ["delayed", "Delayed", "s-hold"], ["failed", "Failed", "s-stop"], ["completed", "Completed", "s-go"]];

const queueCard = (name, c) => html`<div class="panel h-100">
  <div class="panel-head"><h2>${name}</h2></div>
  <div class="panel-body"><div class="readout-lines">${COUNTS.map(([k, l, cls]) => html`<div class="d-flex justify-content-between">${state(cls, l)}<span class="n">${num(c?.[k] ?? 0)}</span></div>`)}</div></div>
</div>`;

export function systemPage(outlet) {
  let disposed = false;
  const running = new Set();
  mount(outlet, html`<div class="page-head"><div><h1>System</h1><div class="sub">Background queues and housekeeping jobs</div></div>
    <button type="button" class="btn btn-outline-secondary btn-sm" id="refresh"><i class="bi bi-arrow-clockwise me-1"></i>Refresh</button></div>
    <div id="body"><div class="panel">${skeletonPanel(5)}</div></div>`);
  const body = outlet.querySelector("#body");

  async function load() {
    try {
      const [q, r] = await Promise.all([api.get("/admin/queues"), api.get("/admin/housekeeping/runs", { limit: 30 })]);
      if (disposed) return;
      const last = new Map();
      for (const run of r.runs) if (!last.has(run.job)) last.set(run.job, run);
      mount(
        body,
        html`<div class="row g-3 mb-3"><div class="col-md-6">${queueCard("Matching queue", q.matching)}</div><div class="col-md-6">${queueCard("Housekeeping queue", q.housekeeping)}</div></div>
        <div class="panel">
          <div class="panel-head"><h2>Housekeeping jobs</h2></div>
          <div class="table-responsive"><table class="table"><thead><tr><th scope="col">Job</th><th scope="col">Last run</th><th scope="col" class="text-end"><span class="visually-hidden">Run</span></th></tr></thead>
          <tbody>${JOBS.map(([key, name, desc]) => {
            const l = last.get(key);
            return html`<tr><td><div class="fw-semibold">${name}</div><div class="cell-sub">${desc}</div></td>
              <td>${l ? html`${l.error ? state("s-stop", "Failed", { title: l.error }) : state("s-go", "OK")} <span class="cell-sub" title="${dateTime(l.startedAt)}">${relTime(l.startedAt)}${l.error ? "" : `, ${num(l.affected ?? 0)} affected`}</span>` : html`<span class="text-body-secondary">Not run yet</span>`}</td>
              <td class="text-end"><button type="button" class="btn btn-sm btn-outline-primary" data-run="${key}" ${running.has(key) ? "disabled" : ""}>Run now</button></td></tr>`;
          })}</tbody></table></div>
        </div>
        <div class="panel mt-3">
          <div class="panel-head"><h2>Recent runs</h2></div>
          ${r.runs.length
            ? html`<div class="table-responsive"><table class="table"><thead><tr><th scope="col">Job</th><th scope="col">Started</th><th scope="col">Result</th></tr></thead><tbody>
                ${r.runs.map((x) => html`<tr><td>${titleCase(x.job.replace(/-/g, " "))}</td><td title="${dateTime(x.startedAt)}">${relTime(x.startedAt)}</td><td>${x.error ? html`<span class="text-danger">${x.error}</span>` : `${num(x.affected ?? 0)} affected`}</td></tr>`)}
              </tbody></table></div>`
            : html`<div class="panel-body text-body-secondary">No runs recorded yet.</div>`}
        </div>`,
      );
    } catch (e) {
      if (!disposed) mount(body, html`<div class="panel">${errorBox(e)}</div>`);
    }
  }

  const refresher = autoRefresh(load, 10000);
  refresher.setEnabled(true);
  const offs = [
    on(outlet, "click", "#refresh", load),
    on(outlet, "click", "[data-retry]", load),
    on(outlet, "click", "[data-run]", async (_e, btn) => {
      const job = btn.getAttribute("data-run");
      running.add(job);
      btn.disabled = true;
      try {
        await api.post(`/admin/housekeeping/${job}/run`, {});
        toast("Job queued. The worker will run it in a moment.", "success");
        setTimeout(() => !disposed && load(), 2000);
      } catch (e) {
        toast(e.message, "danger");
      } finally {
        running.delete(job);
        btn.disabled = false;
      }
    }),
  ];
  load();
  return { unmount() { disposed = true; refresher.stop(); offs.forEach((o) => o()); } };
}
