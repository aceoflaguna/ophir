import { api } from "../lib/api.js";
import { autoRefresh, html, mount, on } from "../lib/dom.js";
import { coords, dateTime, mapUrl, money, num, relTime, shortId, titleCase } from "../lib/format.js";
import { setSection } from "../components/layout.js";
import { avatar, errorBox, plate, rideState, skeletonPanel, standing, state } from "../components/ui.js";

const EVENT_LABEL = {
  requested: "Ride requested",
  offered: "Offer sent to a driver",
  offer_accepted: "Driver accepted",
  offer_declined: "Driver declined",
  offer_expired: "Offer expired",
  accepted: "Driver accepted",
  arrived: "Driver arrived",
  started: "Trip started",
  completed: "Trip completed",
  cancelled: "Cancelled",
  no_drivers: "No drivers found",
  rated: "Rated",
  requeued: "Sent back to matching",
  admin_requeued: "Sent back to matching by moderation",
  admin_cancelled: "Cancelled by moderation",
};
const EVENT_CLS = { completed: "s-go", cancelled: "s-stop", admin_cancelled: "s-stop", no_drivers: "s-idle", offer_declined: "s-hold", offer_expired: "s-hold", requeued: "s-hold", admin_requeued: "s-hold" };
const OFFER_CLS = { accepted: "s-go", declined: "s-hold", expired: "s-idle", pending: "s-route", withdrawn: "s-idle" };

const person = (title, p, extra = "") =>
  p
    ? html`<div class="panel">
        <div class="panel-head"><h2>${title}</h2>${standing({ status: p.accountStatus })}</div>
        <div class="panel-body d-flex gap-3">
          ${avatar(p.name, true)}
          <div class="min-w-0">
            <a class="fw-semibold d-block truncate" href="#/users/${p.id}">${p.name}</a>
            <div class="cell-sub truncate">${p.email}</div>
            <div class="cell-sub">${p.phone ?? "No phone"}</div>
            ${extra}
          </div>
        </div>
      </div>`
    : html`<div class="panel"><div class="panel-head"><h2>${title}</h2></div><div class="panel-body text-body-secondary">No driver was assigned.</div></div>`;

function detailText(e) {
  const d = e.data ?? {};
  const bits = [];
  if (d.reason) bits.push(String(d.reason));
  if (d.by) bits.push(`by ${d.by}`);
  if (d.stars ?? d.rating) bits.push(`${d.stars ?? d.rating} stars`);
  if (d.fare != null) bits.push(`fare ${num(d.fare)}`);
  return bits.join(" · ");
}

export function rideDetailPage(outlet, ctx) {
  const id = ctx.params.id;
  let disposed = false;
  mount(outlet, html`<div class="panel">${skeletonPanel(6)}</div>`);
  setSection("rides");

  async function load({ quiet = false } = {}) {
    try {
      const d = await api.get(`/admin/rides/${id}`);
      if (disposed) return;
      render(d);
      refresher.setEnabled(["searching", "accepted", "arrived", "in_progress"].includes(d.ride.status));
    } catch (e) {
      if (disposed || quiet) return;
      if (e.status === 404) mount(outlet, html`<div class="panel"><div class="empty-state"><i class="bi bi-signpost-split"></i><div class="h5 m-0">Ride not found</div><a class="btn btn-primary" href="#/rides">Back to rides</a></div></div>`);
      else mount(outlet, html`<div class="panel">${errorBox(e)}</div>`);
    }
  }

  function render(d) {
    const r = d.ride;
    const t = r.timestamps;
    const fin = r.final;
    const label = (a) => (a?.address ? a.address : coords(a.lat, a.lng));
    mount(
      outlet,
      html`<nav class="mb-2 small" aria-label="Breadcrumb"><a href="#/rides" class="text-body-secondary">Rides</a></nav>
        <div class="page-head">
          <div><h1>Ride <span class="num">${shortId(r.id)}</span></h1><div class="d-flex flex-wrap gap-2 mt-1 align-items-center">${rideState(r.status)}<span class="text-capitalize cell-sub">${r.vehicleType}</span><span class="cell-sub">Requested ${relTime(t.requestedAt)}</span></div></div>
          <button type="button" class="btn btn-outline-secondary" id="reload" aria-label="Refresh"><i class="bi bi-arrow-clockwise"></i></button>
        </div>
        ${r.cancellation ? html`<div class="restriction s-stop"><div><div class="what">Cancelled by ${r.cancellation.by}</div>${r.cancellation.reason ? html`<div>${r.cancellation.reason}</div>` : ""}</div></div>` : ""}
        <div class="row g-3">
          <div class="col-lg-8">
            <div class="panel">
              <div class="panel-head"><h2>Trip</h2></div>
              <div class="panel-body">
                <div class="route-cell mb-3">
                  <div><i class="bi bi-record-circle"></i><span>${label(r.pickup)} <a class="small ms-1" href="${mapUrl(r.pickup.lat, r.pickup.lng)}" target="_blank" rel="noopener noreferrer">map</a></span></div>
                  <div><i class="bi bi-geo-alt-fill"></i><span>${label(r.dropoff)} <a class="small ms-1" href="${mapUrl(r.dropoff.lat, r.dropoff.lng)}" target="_blank" rel="noopener noreferrer">map</a></span></div>
                </div>
                <div class="stat-grid">
                  <div><div class="v">${money(fin ? fin.fare : r.estimate.fare, r.currency)}</div><div class="l">${fin ? "Final fare" : "Estimated fare"}</div></div>
                  <div><div class="v">${Number(fin ? fin.distanceKm : r.estimate.distanceKm).toFixed(1)} km</div><div class="l">${fin ? "Distance driven" : "Estimated distance"}</div></div>
                  <div><div class="v">${fin ? money(fin.driverEarnings, r.currency) : "-"}</div><div class="l">Driver earnings</div></div>
                  <div><div class="v">${fin ? money(fin.platformFee, r.currency) : "-"}</div><div class="l">Platform fee</div></div>
                  <div><div class="v text-capitalize">${r.paymentMethod}</div><div class="l">Payment method</div></div>
                  <div><div class="v">${r.ratings.riderRating ?? "-"} / ${r.ratings.driverRating ?? "-"}</div><div class="l">Rating given by rider / driver</div></div>
                </div>
              </div>
            </div>
            <div class="panel mt-3">
              <div class="panel-head"><h2>Timeline</h2></div>
              <div class="panel-body">
                ${d.events.length
                  ? html`<ul class="timeline">${d.events.map((e) => {
                      const extra = detailText(e);
                      return html`<li class="${EVENT_CLS[e.type] ?? "s-route"}"><span class="lamp"></span>
                        <div class="fw-semibold">${EVENT_LABEL[e.type] ?? titleCase(e.type)}</div>
                        ${e.actor ? html`<div class="cell-sub">${e.actor.name}</div>` : ""}
                        ${extra ? html`<div class="cell-sub">${extra}</div>` : ""}
                        <div class="when" title="${dateTime(e.createdAt)}">${dateTime(e.createdAt)}</div></li>`;
                    })}</ul>`
                  : html`<div class="text-body-secondary">No events recorded.</div>`}
              </div>
            </div>
            <div class="panel mt-3">
              <div class="panel-head"><h2>Driver offers</h2></div>
              ${d.offers.length
                ? html`<div class="table-responsive"><table class="table"><thead><tr><th scope="col">Driver</th><th scope="col">Outcome</th><th scope="col">Distance</th><th scope="col">Sent</th></tr></thead>
                    <tbody>${d.offers.map((o) => html`<tr><td><a href="#/users/${o.driver.id}" class="text-reset">${o.driver.name}</a></td><td>${state(OFFER_CLS[o.status] ?? "s-idle", titleCase(o.status))}</td><td class="num">${o.distanceKm != null ? `${Number(o.distanceKm).toFixed(1)} km` : "-"}</td><td title="${dateTime(o.createdAt)}">${relTime(o.createdAt)}</td></tr>`)}</tbody></table></div>`
                : html`<div class="panel-body text-body-secondary">No offers were sent for this ride.</div>`}
            </div>
          </div>
          <div class="col-lg-4">
            ${person("Rider", d.rider)}
            <div class="mt-3">${person("Driver", d.driver, d.driver ? html`<div class="mt-2">${plate(d.driver.vehicle.plate)} <span class="cell-sub">${d.driver.vehicle.color} ${d.driver.vehicle.make} ${d.driver.vehicle.model}</span></div>` : "")}</div>
            <div class="panel mt-3">
              <div class="panel-head"><h2>Payment</h2></div>
              <div class="panel-body">${d.payment
                ? html`<dl class="kv"><dt>Amount</dt><dd class="num">${money(d.payment.amount, d.payment.currency)}</dd><dt>Method</dt><dd class="text-capitalize">${d.payment.method}</dd><dt>Status</dt><dd class="text-capitalize">${d.payment.status}</dd><dt>When</dt><dd>${dateTime(d.payment.createdAt)}</dd></dl>`
                : html`<span class="text-body-secondary">No payment recorded.</span>`}</div>
            </div>
          </div>
        </div>`,
    );
  }

  const refresher = autoRefresh(() => load({ quiet: true }), 8000);
  const offs = [on(outlet, "click", "#reload", () => load()), on(outlet, "click", "[data-retry]", () => load())];
  load();
  return {
    unmount() {
      disposed = true;
      refresher.stop();
      offs.forEach((o) => o());
    },
  };
}
