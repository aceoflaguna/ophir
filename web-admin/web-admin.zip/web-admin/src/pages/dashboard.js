import { api } from "../lib/api.js";
import { autoRefresh, html, mount, on } from "../lib/dom.js";
import { href } from "../lib/router.js";
import { money, num, relTime } from "../lib/format.js";
import { errorBox, skeletonPanel, state } from "../components/ui.js";

const ACTION_TEXT = {
  suspend: ["suspended", "s-hold"],
  ban: ["banned", "s-stop"],
  reinstate: ["reinstated", "s-go"],
  auto_reinstate: ["reinstated automatically", "s-go"],
};

const line = (cls, label, n, to, pulse = false) =>
  html`<a href="${to}">${state(cls, label, { pulse })}<span class="n">${num(n)}</span></a>`;

function weekday(day, i, last) {
  if (i === last) return "Today";
  return new Date(`${day}T12:00:00`).toLocaleDateString(undefined, { weekday: "short" });
}

function board(s) {
  const { riders, drivers, rides, today, currency } = s;
  return html`<div class="panel board" aria-label="Fleet right now">
    <div>
      <div class="readout-label">Riders</div>
      <div class="readout-value">${num(riders.total)}</div>
      <div class="readout-lines">
        ${line("s-go", "Active", riders.active, href("/riders", { status: "active" }))}
        ${line("s-hold", "Suspended", riders.suspended, href("/riders", { status: "suspended" }))}
        ${line("s-stop", "Banned", riders.banned, href("/riders", { status: "banned" }))}
      </div>
      <div class="cell-sub mt-2">${num(riders.new7d)} joined this week</div>
    </div>
    <div>
      <div class="readout-label">Drivers</div>
      <div class="readout-value">${num(drivers.total)}</div>
      <div class="readout-lines">
        ${line("s-go", "Online", drivers.online, href("/drivers", { driverStatus: "online" }), drivers.online > 0)}
        ${line("s-route", "On a trip", drivers.busy, href("/drivers", { driverStatus: "busy" }))}
        ${line("s-idle", "Offline", drivers.offline, href("/drivers", { driverStatus: "offline" }))}
        ${line("s-hold", "Suspended", drivers.suspended, href("/drivers", { status: "suspended" }))}
        ${line("s-stop", "Banned", drivers.banned, href("/drivers", { status: "banned" }))}
      </div>
    </div>
    <div>
      <div class="readout-label">Rides in progress</div>
      <div class="readout-value">${num(rides.live)}</div>
      <div class="readout-lines">
        ${line("s-hold", "Searching for a driver", rides.searching, href("/rides", { status: "searching" }), rides.searching > 0)}
        ${line("s-route", "On the road", rides.inProgress, href("/rides", { status: "in_progress" }))}
      </div>
      <div class="cell-sub mt-2">${num(rides.completed)} completed, ${num(rides.cancelled)} cancelled all time</div>
    </div>
    <div>
      <div class="readout-label">Trips completed today</div>
      <div class="readout-value">${num(today.completed)} <small>of ${num(today.requested)} requested</small></div>
      <div class="readout-lines">
        <div class="d-flex justify-content-between"><span>Fares</span><span class="n">${money(today.gross, currency)}</span></div>
        <div class="d-flex justify-content-between"><span>Platform fees</span><span class="n">${money(today.platformFees, currency)}</span></div>
      </div>
    </div>
  </div>`;
}

function chart(daily) {
  const max = Math.max(1, ...daily.map((d) => d.total));
  const any = daily.some((d) => d.total > 0);
  return html`<div class="panel h-100">
    <div class="panel-head">
      <h2>Rides over the last 7 days</h2>
      <div class="small text-body-secondary">
        <span class="legend-swatch" style="background:color-mix(in srgb, var(--route) 18%, var(--fa-panel))"></span>Requested
        <span class="legend-swatch ms-3" style="background:var(--route)"></span>Completed
      </div>
    </div>
    <div class="panel-body">
      ${any
        ? html`<div class="bars" role="img" aria-label="Daily rides requested and completed for the last 7 days">
            ${daily.map(
              (d, i) => html`<div class="bar-col" title="${d.day}: ${d.total} requested, ${d.completed} completed">
                <span class="bar-val">${num(d.total)}</span>
                <div class="bar-stack" style="height:${Math.max(2, (d.total / max) * 100)}%">
                  <div class="bar-fill" style="height:${d.total ? (d.completed / d.total) * 100 : 0}%"></div>
                </div>
                <span class="bar-day">${weekday(d.day, i, daily.length - 1)}</span>
              </div>`,
            )}
          </div>`
        : html`<div class="text-body-secondary py-4 text-center">No rides requested in the last 7 days.</div>`}
    </div>
  </div>`;
}

function moderationFeed(items) {
  return html`<div class="panel h-100">
    <div class="panel-head"><h2>Recent account actions</h2></div>
    ${items.length
      ? html`<div class="panel-body"><ul class="timeline">
          ${items.map((m) => {
            const [verb, cls] = ACTION_TEXT[m.action] ?? [m.action, "s-idle"];
            return html`<li class="${cls}">
              <span class="lamp"></span>
              <div><a href="#/users/${m.user.id}" class="fw-semibold text-reset">${m.user.name}</a> was ${verb}${m.admin ? html` by ${m.admin}` : ""}</div>
              ${m.reason ? html`<div class="cell-sub">${m.reason}</div>` : ""}
              <div class="when">${relTime(m.createdAt)}</div>
            </li>`;
          })}
        </ul></div>`
      : html`<div class="panel-body text-body-secondary">No accounts have been suspended or banned yet.</div>`}
  </div>`;
}

export function dashboardPage(outlet) {
  let disposed = false;
  let seq = 0;

  mount(
    outlet,
    html`<div class="page-head">
        <div><h1>Dashboard</h1><div class="sub" id="updated">Loading</div></div>
        <div class="d-flex align-items-center gap-3">
          <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" role="switch" id="live" checked><label class="form-check-label" for="live">Auto-refresh</label></div>
          <button type="button" class="btn btn-outline-secondary btn-sm" id="refresh"><i class="bi bi-arrow-clockwise me-1"></i>Refresh</button>
        </div>
      </div>
      <div id="body"><div class="panel">${skeletonPanel(5)}</div></div>`,
  );
  const body = outlet.querySelector("#body");

  async function load() {
    const my = ++seq;
    try {
      const s = await api.get("/admin/stats");
      if (disposed || my !== seq) return;
      mount(body, html`${board(s)}<div class="row g-3 mt-0"><div class="col-lg-7">${chart(s.daily)}</div><div class="col-lg-5">${moderationFeed(s.recentModeration)}</div></div>`);
      outlet.querySelector("#updated").textContent = `Updated ${new Date().toLocaleTimeString()}`;
    } catch (e) {
      if (disposed || my !== seq) return;
      mount(body, html`<div class="panel">${errorBox(e)}</div>`);
    }
  }

  const refresher = autoRefresh(load, 15000);
  refresher.setEnabled(true);
  const offs = [
    on(outlet, "click", "#refresh", load),
    on(outlet, "click", "[data-retry]", load),
    on(outlet, "change", "#live", (_e, el) => refresher.setEnabled(el.checked)),
  ];
  load();

  return {
    unmount() {
      disposed = true;
      refresher.stop();
      offs.forEach((off) => off());
    },
  };
}
