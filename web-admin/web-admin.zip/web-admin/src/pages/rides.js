import { api } from "../lib/api.js";
import { autoRefresh, debounce, html, mount, on } from "../lib/dom.js";
import { navigate, setQuery } from "../lib/router.js";
import { coords, money, num, relTime, dateTime, shortId } from "../lib/format.js";
import { bindPager, pager } from "../components/pagination.js";
import { emptyState, errorBox, rideState, skeletonRows } from "../components/ui.js";

const LIMIT = 20;
const TABS = [
  ["", "All"],
  ["active", "Live"],
  ["completed", "Completed"],
  ["cancelled", "Cancelled"],
  ["no_drivers", "No drivers"],
];

const place = (p) => p.address ?? coords(p.lat, p.lng);

export function ridesPage(outlet, ctx) {
  const s = {
    q: ctx.query.q ?? "",
    status: ctx.query.status ?? "",
    userId: ctx.query.userId ?? "",
    page: Math.max(1, Number(ctx.query.page) || 1),
  };
  let disposed = false;
  let seq = 0;
  const liveDefault = s.status === "active" || s.status === "searching" || s.status === "in_progress" || s.status === "";

  mount(
    outlet,
    html`<div class="page-head">
        <div><h1>Rides</h1><div class="sub" id="count"></div></div>
        <div class="d-flex align-items-center gap-3">
          <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" role="switch" id="live" ${liveDefault ? "checked" : ""}><label class="form-check-label" for="live">Auto-refresh</label></div>
          <button type="button" class="btn btn-outline-secondary btn-sm" id="refresh"><i class="bi bi-arrow-clockwise me-1"></i>Refresh</button>
        </div>
      </div>
      <div class="panel">
        <div class="filters" id="filters">
          <ul class="nav nav-pills" id="tabs" role="tablist" aria-label="Ride status"></ul>
          <div class="grow"><input type="search" class="form-control" id="q" placeholder="Search by person, address or ride ID" value="${s.q}" aria-label="Search rides"></div>
        </div>
        <div id="chip"></div>
        <div id="list"></div>
        <div id="pager"></div>
      </div>`,
  );
  const listEl = outlet.querySelector("#list");
  const pagerEl = outlet.querySelector("#pager");
  const countEl = outlet.querySelector("#count");
  const tabsEl = outlet.querySelector("#tabs");
  const chipEl = outlet.querySelector("#chip");

  function drawChrome() {
    mount(
      tabsEl,
      html`${TABS.map(([v, l]) => html`<li class="nav-item"><button type="button" class="nav-link ${s.status === v ? "active" : ""}" data-tab="${v}">${l}</button></li>`)}`,
    );
    mount(
      chipEl,
      s.userId
        ? html`<div class="px-3 pb-2"><span class="badge text-bg-secondary fw-normal">Rides for user ${shortId(s.userId)} <a href="#/users/${s.userId}" class="text-reset ms-1">view</a> <button type="button" class="btn-close btn-close-white ms-1" style="font-size:.6rem" data-clear-user aria-label="Remove user filter"></button></span></div>`
        : "",
    );
  }
  drawChrome();

  const persist = () => setQuery({ q: s.q, status: s.status, userId: s.userId, page: s.page > 1 ? s.page : "" });

  async function load({ quiet = false } = {}) {
    const my = ++seq;
    if (!quiet) mount(listEl, skeletonRows(7));
    try {
      const data = await api.get("/admin/rides", { status: s.status, q: s.q, userId: s.userId, limit: LIMIT, offset: (s.page - 1) * LIMIT });
      if (disposed || my !== seq) return;
      if (!data.items.length && data.total > 0 && s.page > 1) {
        s.page = 1;
        persist();
        return load();
      }
      countEl.textContent = data.total === 1 ? "1 ride" : `${num(data.total)} rides`;
      if (!data.items.length) {
        mount(listEl, emptyState({ icon: "bi-signpost-split", title: "No rides found", text: s.q || s.status || s.userId ? "Try a different search or status." : "Rides appear here as riders request them." }));
        mount(pagerEl, "");
        return;
      }
      mount(
        listEl,
        html`<div class="table-responsive"><table class="table table-hover">
          <thead><tr><th scope="col">Status</th><th scope="col">Route</th><th scope="col">Rider</th><th scope="col">Driver</th><th scope="col">Fare</th><th scope="col">Requested</th></tr></thead>
          <tbody>${data.items.map(
            (r) => html`<tr class="clickable" data-ride="${r.id}">
              <td>${rideState(r.status)}${r.cancelledBy ? html`<div class="cell-sub">by ${r.cancelledBy}</div>` : ""}</td>
              <td><div class="route-cell"><div><i class="bi bi-record-circle"></i><span class="truncate">${place(r.pickup)}</span></div><div><i class="bi bi-geo-alt-fill"></i><span class="truncate">${place(r.dropoff)}</span></div></div></td>
              <td><a href="#/users/${r.rider.id}" class="text-reset">${r.rider.name}</a></td>
              <td>${r.driver ? html`<a href="#/users/${r.driver.id}" class="text-reset">${r.driver.name}</a>` : html`<span class="text-body-secondary">Unassigned</span>`}</td>
              <td class="num">${money(r.fare, r.currency)}${r.isFinalFare ? "" : html` <span class="cell-sub">est.</span>`}</td>
              <td title="${dateTime(r.requestedAt)}">${relTime(r.requestedAt)}</td>
            </tr>`,
          )}</tbody>
        </table></div>`,
      );
      mount(pagerEl, pager({ total: data.total, limit: LIMIT, offset: (s.page - 1) * LIMIT }));
    } catch (e) {
      if (disposed || my !== seq) return;
      mount(listEl, errorBox(e));
      mount(pagerEl, "");
    }
  }

  const refresher = autoRefresh(() => load({ quiet: true }), 10000);
  refresher.setEnabled(liveDefault);
  const search = debounce(() => {
    s.page = 1;
    persist();
    load();
  }, 300);

  const offs = [
    on(outlet, "input", "#q", (_e, el) => {
      s.q = el.value.trim();
      search();
    }),
    on(outlet, "click", "[data-tab]", (_e, b) => {
      s.status = b.getAttribute("data-tab");
      s.page = 1;
      persist();
      drawChrome();
      load();
    }),
    on(outlet, "click", "[data-clear-user]", () => {
      s.userId = "";
      s.page = 1;
      persist();
      drawChrome();
      load();
    }),
    on(outlet, "click", "#refresh", () => load()),
    on(outlet, "click", "[data-retry]", () => load()),
    on(outlet, "change", "#live", (_e, el) => refresher.setEnabled(el.checked)),
    on(outlet, "click", "tr[data-ride]", (e, tr) => {
      if (e.target.closest("a")) return;
      navigate(`/rides/${tr.getAttribute("data-ride")}`);
    }),
    bindPager(outlet, (n) => {
      s.page = n;
      persist();
      load();
      window.scrollTo({ top: 0 });
    }),
  ];

  load();
  return {
    unmount() {
      disposed = true;
      search.cancel();
      refresher.stop();
      offs.forEach((off) => off());
    },
  };
}
