import { Dropdown } from "bootstrap";
import { api } from "../lib/api.js";
import { autoRefresh, debounce, html, mount, on } from "../lib/dom.js";
import { navigate, setQuery } from "../lib/router.js";
import { num, relTime, date } from "../lib/format.js";
import { openModeration } from "../components/moderation.js";
import { bindPager, pager } from "../components/pagination.js";
import { avatar, driverState, emptyState, errorBox, plate, rating, roleTag, skeletonRows, standing } from "../components/ui.js";

const LIMIT = 20;

function actionMenu(u) {
  const items = [];
  if (u.account.status !== "banned") {
    items.push(html`<li><button class="dropdown-item" type="button" data-mod="suspend" data-id="${u.id}">${u.account.status === "suspended" ? "Change suspension" : "Suspend"}</button></li>`);
    items.push(html`<li><button class="dropdown-item text-danger" type="button" data-mod="ban" data-id="${u.id}">Ban</button></li>`);
  }
  if (u.account.status !== "active") items.push(html`<li><button class="dropdown-item" type="button" data-mod="reinstate" data-id="${u.id}">Reinstate</button></li>`);
  return html`<div class="dropdown">
    <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Actions for ${u.fullName}"><i class="bi bi-three-dots"></i></button>
    <ul class="dropdown-menu dropdown-menu-end">
      <li><a class="dropdown-item" href="#/users/${u.id}">View details</a></li>
      <li><hr class="dropdown-divider"></li>
      ${items}
    </ul>
  </div>`;
}

const nameCell = (u) => html`<div class="d-flex align-items-center gap-2">
  ${avatar(u.fullName)}
  <div class="min-w-0">
    <a class="fw-semibold text-reset text-decoration-none d-block truncate" href="#/users/${u.id}">${u.fullName}</a>
    <div class="cell-sub truncate">${u.email}</div>
  </div>
</div>`;

function vehicleCell(u) {
  const v = u.driver?.vehicle;
  if (!v) return html`<span class="text-body-secondary">No vehicle yet</span>`;
  return html`${plate(v.plate)}<div class="cell-sub">${v.color} ${v.make} ${v.model}</div>`;
}

function driverStateCell(u) {
  if (!u.driver) return html`<span class="text-body-secondary">Not set up</span>`;
  const seen = u.driver.location?.lastSeenAt;
  return html`${driverState(u.driver.status)}${seen ? html`<div class="cell-sub">Seen ${relTime(seen)}</div>` : ""}`;
}

function table(role, items) {
  const cols = {
    driver: ["Driver", "Standing", "Vehicle", "Status", "Rating", "Trips", "Joined"],
    rider: ["Rider", "Standing", "Phone", "Rating", "Trips", "Last sign-in", "Joined"],
    mixed: ["Person", "Role", "Standing", "Rating", "Trips", "Joined"],
  }[role ?? "mixed"];

  const row = (u) => {
    const cells = {
      driver: html`<td>${standing(u.account, { detail: true })}</td><td>${vehicleCell(u)}</td><td>${driverStateCell(u)}</td><td>${rating(u.rating)}</td><td class="num">${num(u.ridesTotal)}</td><td title="${date(u.createdAt)}">${relTime(u.createdAt)}</td>`,
      rider: html`<td>${standing(u.account, { detail: true })}</td><td>${u.phone ?? html`<span class="text-body-secondary">None</span>`}</td><td>${rating(u.rating)}</td><td class="num">${num(u.ridesTotal)}</td><td>${relTime(u.lastLoginAt)}</td><td title="${date(u.createdAt)}">${relTime(u.createdAt)}</td>`,
      mixed: html`<td>${roleTag(u.role)}${u.driver ? html`<div class="mt-1">${driverState(u.driver.status)}</div>` : ""}</td><td>${standing(u.account, { detail: true })}</td><td>${rating(u.rating)}</td><td class="num">${num(u.ridesTotal)}</td><td title="${date(u.createdAt)}">${relTime(u.createdAt)}</td>`,
    }[role ?? "mixed"];
    return html`<tr class="clickable" data-id="${u.id}"><td>${nameCell(u)}</td>${cells}<td class="text-end">${actionMenu(u)}</td></tr>`;
  };

  return html`<div class="table-responsive"><table class="table table-hover">
    <thead><tr>${cols.map((c) => html`<th scope="col">${c}</th>`)}<th scope="col"><span class="visually-hidden">Actions</span></th></tr></thead>
    <tbody>${items.map(row)}</tbody>
  </table></div>`;
}

/**
 * Directory page. role: "driver" | "rider" | undefined (search across everyone).
 */
export function usersPage({ role, title, liveDefault = false }) {
  return (outlet, ctx) => {
    const s = {
      q: ctx.query.q ?? "",
      status: ctx.query.status ?? "",
      driverStatus: role === "driver" ? (ctx.query.driverStatus ?? "") : "",
      sort: ctx.query.sort ?? "newest",
      page: Math.max(1, Number(ctx.query.page) || 1),
    };
    let disposed = false;
    let seq = 0;
    let items = [];

    mount(
      outlet,
      html`<div class="page-head">
          <div><h1>${title}</h1><div class="sub" id="count"></div></div>
          <div class="d-flex align-items-center gap-3">
            <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" role="switch" id="live" ${liveDefault ? "checked" : ""}><label class="form-check-label" for="live">Auto-refresh</label></div>
            <button type="button" class="btn btn-outline-secondary btn-sm" id="refresh"><i class="bi bi-arrow-clockwise me-1"></i>Refresh</button>
          </div>
        </div>
        <div class="panel">
          <form class="filters" id="filters" role="search" aria-label="Filter ${title.toLowerCase()}">
            <div class="grow"><input type="search" class="form-control" id="q" placeholder="Search by name, email, phone${role !== "rider" ? ", plate" : ""} or ID" value="${s.q}" aria-label="Search"></div>
            <select class="form-select" id="status" aria-label="Account standing">
              ${[["", "Any standing"], ["active", "Active"], ["suspended", "Suspended"], ["banned", "Banned"]].map(([v, l]) => html`<option value="${v}" ${s.status === v ? "selected" : ""}>${l}</option>`)}
            </select>
            ${role === "driver" ? html`<select class="form-select" id="driverStatus" aria-label="Driver status">
              ${[["", "Any status"], ["online", "Online"], ["busy", "On a trip"], ["offline", "Offline"]].map(([v, l]) => html`<option value="${v}" ${s.driverStatus === v ? "selected" : ""}>${l}</option>`)}
            </select>` : ""}
            <select class="form-select" id="sort" aria-label="Sort by">
              ${[["newest", "Newest first"], ["oldest", "Oldest first"], ["name", "Name"], ["rating", "Highest rated"], ["rides", "Most trips"], ["lastLogin", "Recent sign-in"]].map(([v, l]) => html`<option value="${v}" ${s.sort === v ? "selected" : ""}>${l}</option>`)}
            </select>
          </form>
          <div id="list"></div>
          <div id="pager"></div>
        </div>`,
    );
    const listEl = outlet.querySelector("#list");
    const pagerEl = outlet.querySelector("#pager");
    const countEl = outlet.querySelector("#count");
    const colCount = { driver: 8, rider: 8, mixed: 7 }[role ?? "mixed"];

    const persist = () =>
      setQuery({
        q: s.q,
        status: s.status,
        driverStatus: s.driverStatus,
        sort: s.sort === "newest" ? "" : s.sort,
        page: s.page > 1 ? s.page : "",
      });

    async function load({ quiet = false } = {}) {
      const my = ++seq;
      if (!quiet) mount(listEl, skeletonRows(colCount));
      try {
        const data = await api.get("/admin/users", {
          role,
          q: s.q,
          status: s.status,
          driverStatus: s.driverStatus,
          sort: s.sort,
          limit: LIMIT,
          offset: (s.page - 1) * LIMIT,
        });
        if (disposed || my !== seq) return;
        // landed past the last page (e.g. after a filter change): go back to the first
        if (data.items.length === 0 && data.total > 0 && s.page > 1) {
          s.page = 1;
          persist();
          return load();
        }
        items = data.items;
        countEl.textContent = data.total === 1 ? "1 person" : `${num(data.total)} people`;
        if (!data.items.length) {
          const filtered = s.q || s.status || s.driverStatus;
          mount(
            listEl,
            emptyState({
              icon: "bi-search",
              title: filtered ? `No ${title.toLowerCase()} match these filters` : `No ${title.toLowerCase()} yet`,
              text: filtered ? "Try a different search or clear the filters." : "They'll appear here as people sign up.",
              action: filtered ? html`<button type="button" class="btn btn-outline-secondary" data-clear>Clear filters</button>` : "",
            }),
          );
          mount(pagerEl, "");
          return;
        }
        mount(listEl, table(role, items));
        listEl.querySelectorAll('[data-bs-toggle="dropdown"]').forEach((el) => new Dropdown(el, { popperConfig: { strategy: "fixed" } }));
        mount(pagerEl, pager({ total: data.total, limit: LIMIT, offset: (s.page - 1) * LIMIT }));
      } catch (e) {
        if (disposed || my !== seq) return;
        mount(listEl, errorBox(e));
        mount(pagerEl, "");
      }
    }

    const refresher = autoRefresh(() => load({ quiet: true }), 20000);
    refresher.setEnabled(liveDefault);

    const search = debounce(() => {
      s.page = 1;
      persist();
      load();
    }, 300);
    const q = outlet.querySelector("#q");

    const offs = [
      on(outlet, "input", "#q", (_e, el) => {
        s.q = el.value.trim();
        search();
      }),
      on(outlet, "change", "#status, #driverStatus, #sort", (_e, el) => {
        s[el.id] = el.value;
        s.page = 1;
        persist();
        load();
      }),
      on(outlet, "submit", "#filters", (e) => e.preventDefault()),
      on(outlet, "click", "#refresh", () => load()),
      on(outlet, "click", "[data-retry]", () => load()),
      on(outlet, "click", "[data-clear]", () => {
        Object.assign(s, { q: "", status: "", driverStatus: "", page: 1 });
        q.value = "";
        outlet.querySelectorAll("#status, #driverStatus").forEach((el) => (el.value = ""));
        persist();
        load();
      }),
      on(outlet, "change", "#live", (_e, el) => refresher.setEnabled(el.checked)),
      // row click opens the detail page (but not when using the actions menu or links)
      on(outlet, "click", "tr.clickable", (e, tr) => {
        if (e.target.closest("a, button, .dropdown")) return;
        navigate(`/users/${tr.getAttribute("data-id")}`);
      }),
      on(outlet, "click", "[data-mod]", (_e, btn) => {
        const u = items.find((x) => x.id === btn.getAttribute("data-id"));
        if (u) openModeration({ action: btn.getAttribute("data-mod"), user: u, onDone: () => load({ quiet: true }) });
      }),
      bindPager(outlet, (n) => {
        s.page = n;
        persist();
        load();
        window.scrollTo({ top: 0 });
      }),
    ];

    load();
    return {
      unmount() {
        disposed = true;
        search.cancel();
        refresher.stop();
        offs.forEach((off) => off());
      },
    };
  };
}

