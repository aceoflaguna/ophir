import { html, mount } from "../lib/dom.js";
import { login } from "../lib/auth.js";

/** Renders the sign-in screen into `root`. `onSuccess()` runs after an admin signs in. */
export function renderLogin(root, { notice = "", onSuccess }) {
  mount(
    root,
    html`<div class="login">
      <section class="login-art" aria-hidden="true">
        <div class="d-flex align-items-center gap-2">
          <span class="brand-mark"><svg width="16" height="20" viewBox="0 0 16 20"><path d="M8 1v4M8 8v4M8 15v4" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/></svg></span>
          <span class="brand-name">Fleet Admin</span>
        </div>
        <div>
          <h1>Keep every trip and every account in good standing.</h1>
          <p class="mt-3 mb-0">Look up riders and drivers, review their history, and suspend, ban or reinstate accounts.</p>
        </div>
        <div class="small" style="color:#8f9cab">Administrators only</div>
      </section>
      <section class="login-form">
        <form id="login-form" novalidate>
          <h2 class="h3 mb-1">Sign in</h2>
          <p class="text-body-secondary mb-4">Use your administrator account.</p>
          <div id="login-alert" class="alert ${notice ? "alert-warning" : "alert-danger d-none"}" role="alert">${notice}</div>
          <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input class="form-control" id="email" name="email" type="email" autocomplete="username" required autofocus>
          </div>
          <div class="mb-4">
            <label class="form-label" for="password">Password</label>
            <input class="form-control" id="password" name="password" type="password" autocomplete="current-password" required>
          </div>
          <button class="btn btn-primary w-100" type="submit" id="login-btn"><span class="spinner-border spinner-border-sm me-2 d-none" aria-hidden="true"></span>Sign in</button>
        </form>
      </section>
    </div>`,
  );

  const form = root.querySelector("#login-form");
  const alert = root.querySelector("#login-alert");
  const btn = root.querySelector("#login-btn");
  const spin = btn.querySelector(".spinner-border");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = form.email.value.trim();
    const password = form.password.value;
    alert.classList.add("d-none");
    if (!email || !password) {
      alert.className = "alert alert-danger";
      alert.textContent = "Enter your email and password.";
      return;
    }
    btn.disabled = true;
    spin.classList.remove("d-none");
    try {
      await login(email, password);
      onSuccess();
    } catch (err) {
      alert.className = "alert alert-danger";
      alert.textContent =
        err.code === "INVALID_CREDENTIALS" ? "That email and password don't match. Check them and try again." : err.message;
      form.password.value = "";
      form.password.focus();
    } finally {
      btn.disabled = false;
      spin.classList.add("d-none");
    }
  });
}
