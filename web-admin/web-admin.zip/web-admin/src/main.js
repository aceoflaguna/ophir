import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "@fontsource/barlow/400.css";
import "@fontsource/barlow/500.css";
import "@fontsource/barlow/600.css";
import "@fontsource/barlow-semi-condensed/500.css";
import "@fontsource/barlow-semi-condensed/600.css";
import "./styles/app.css";

import { setAuthLostHandler } from "./lib/api.js";
import { restore, logout } from "./lib/auth.js";
import { route, startRouter } from "./lib/router.js";
import { renderShell, sectionForPath, setSection, setTheme } from "./components/layout.js";
import { renderLogin } from "./pages/login.js";
import { dashboardPage } from "./pages/dashboard.js";
import { usersPage } from "./pages/users.js";
import { userDetailPage } from "./pages/user-detail.js";
import { ridesPage } from "./pages/rides.js";
import { rideDetailPage } from "./pages/ride-detail.js";
import { systemPage } from "./pages/system.js";

const root = document.getElementById("app");
let stopRouter = null;

try {
  setTheme(localStorage.getItem("fleet-admin.theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
} catch {
  /* ignore */
}

route("/dashboard", dashboardPage);
route("/riders", usersPage({ role: "rider", title: "Riders" }));
route("/drivers", usersPage({ role: "driver", title: "Drivers", liveDefault: true }));
route("/people", usersPage({ title: "Search results" }));
route("/users/:id", userDetailPage);
route("/rides", ridesPage);
route("/rides/:id", rideDetailPage);
route("/system", systemPage);

function showLogin(notice = "") {
  stopRouter?.();
  stopRouter = null;
  renderLogin(root, { notice, onSuccess: showApp });
}

function showApp() {
  stopRouter?.();
  const { view } = renderShell(root, {
    onLogout: async () => {
      await logout();
      showLogin();
    },
  });
  if (!window.location.hash || window.location.hash === "#/") window.location.hash = "#/dashboard";
  stopRouter = startRouter(view, { onRoute: (path) => setSection(sectionForPath(path)) });
}

setAuthLostHandler(() => showLogin("Your session ended. Please sign in again."));

(async () => {
  (await restore()) ? showApp() : showLogin();
})();
