import { html, on } from "../lib/dom.js";
import { num } from "../lib/format.js";

/** Footer with "Showing 21-40 of 134" and a compact page list. Wire it with bindPager(). */
export function pager({ total, limit, offset }) {
  if (!total) return "";
  const page = Math.floor(offset / limit) + 1;
  const pages = Math.max(1, Math.ceil(total / limit));
  const from = offset + 1;
  const to = Math.min(offset + limit, total);

  const nums = new Set([1, pages, page - 1, page, page + 1]);
  const list = [...nums].filter((n) => n >= 1 && n <= pages).sort((a, b) => a - b);
  const items = [];
  list.forEach((n, i) => {
    if (i > 0 && n - list[i - 1] > 1) items.push(html`<li class="page-item disabled"><span class="page-link">…</span></li>`);
    items.push(html`<li class="page-item ${n === page ? "active" : ""}"><button type="button" class="page-link" data-page="${n}" ${n === page ? 'aria-current="page"' : ""}>${n}</button></li>`);
  });

  return html`<div class="pager">
    <span>Showing ${num(from)} to ${num(to)} of ${num(total)}</span>
    ${pages > 1 ? html`<nav aria-label="Pages"><ul class="pagination pagination-sm m-0">
      <li class="page-item ${page === 1 ? "disabled" : ""}"><button type="button" class="page-link" data-page="${page - 1}" aria-label="Previous page">Previous</button></li>
      ${items}
      <li class="page-item ${page === pages ? "disabled" : ""}"><button type="button" class="page-link" data-page="${page + 1}" aria-label="Next page">Next</button></li>
    </ul></nav>` : ""}
  </div>`;
}

export function bindPager(root, onPage) {
  return on(root, "click", "[data-page]", (_e, el) => {
    const n = Number(el.getAttribute("data-page"));
    if (n >= 1) onPage(n);
  });
}
