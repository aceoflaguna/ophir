import { Offcanvas } from "bootstrap";
import { html, mount } from "../lib/dom.js";
import { navigate } from "../lib/router.js";
import { session } from "../lib/auth.js";

const NAV = [
  ["dashboard", "Dashboard", "bi-grid-1x2", "#/dashboard"],
  ["riders", "Riders", "bi-person", "#/riders"],
  ["drivers", "Drivers", "bi-car-front", "#/drivers"],
  ["rides", "Rides", "bi-signpost-split", "#/rides"],
  ["system", "System", "bi-gear", "#/system"],
];

const SECTION_BY_PREFIX = [
  [/^\/dashboard/, "dashboard"],
  [/^\/riders/, "riders"],
  [/^\/drivers/, "drivers"],
  [/^\/rides/, "rides"],
  [/^\/system/, "system"],
];

export function setTheme(t) {
  document.documentElement.setAttribute("data-bs-theme", t);
  try {
    localStorage.setItem("fleet-admin.theme", t);
  } catch {
    /* ignore */
  }
  const icon = document.querySelector("#theme-toggle i");
  if (icon) icon.className = t === "dark" ? "bi bi-sun" : "bi bi-moon";
}

/** Highlight a sidebar section (pages like user detail pick the section from the user's role). */
export function setSection(section) {
  document.querySelectorAll("#sidebar [data-section]").forEach((a) => {
    const on = a.getAttribute("data-section") === section;
    a.classList.toggle("active", on);
    if (on) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
}
export const sectionForPath = (path) => SECTION_BY_PREFIX.find(([rx]) => rx.test(path))?.[1] ?? null;

export function renderShell(root, { onLogout }) {
  const user = session.user;
  mount(
    root,
    html`<div class="app-shell d-flex">
      <aside id="sidebar" class="sidebar offcanvas-lg offcanvas-start d-flex flex-column" tabindex="-1" aria-label="Main">
        <div class="d-flex align-items-start justify-content-between">
          <a class="brand" href="#/dashboard">
            <span class="brand-mark" aria-hidden="true"><svg width="16" height="20" viewBox="0 0 16 20"><path d="M8 1v4M8 8v4M8 15v4" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/></svg></span>
            <span><span class="brand-name d-block">Fleet Admin</span><span class="brand-sub">Riders, drivers, rides</span></span>
          </a>
          <button type="button" class="btn-close btn-close-white d-lg-none m-3" data-bs-dismiss="offcanvas" data-bs-target="#sidebar" aria-label="Close menu"></button>
        </div>
        <nav class="nav flex-column mt-2" aria-label="Sections">
          ${NAV.map(([key, label, icon, href]) => html`<a class="nav-link" href="${href}" data-section="${key}"><i class="bi ${icon}"></i>${label}</a>`)}
        </nav>
        <div class="sidebar-foot">
          <div class="who truncate">${user?.fullName ?? "Admin"}</div>
          <div class="small mb-2 truncate">${user?.email ?? ""}</div>
          <button type="button" class="btn btn-link" id="logout"><i class="bi bi-box-arrow-left me-1"></i>Sign out</button>
        </div>
      </aside>

      <div class="flex-grow-1 min-w-0 d-flex flex-column">
        <header class="topbar">
          <button type="button" class="btn btn-outline-secondary d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar" aria-label="Open menu"><i class="bi bi-list"></i></button>
          <form class="search" id="global-search" role="search">
            <div class="input-group">
              <span class="input-group-text bg-transparent"><i class="bi bi-search"></i></span>
              <input type="search" class="form-control" id="global-q" placeholder="Find a rider or driver by name, email, phone or plate" aria-label="Find a rider or driver">
            </div>
          </form>
          <div class="ms-auto d-flex align-items-center gap-2">
            <button type="button" class="btn btn-outline-secondary" id="theme-toggle" aria-label="Toggle dark mode"><i class="bi bi-moon"></i></button>
          </div>
        </header>
        <main id="view" class="view mx-auto" tabindex="-1"></main>
      </div>
    </div>`,
  );

  setTheme(document.documentElement.getAttribute("data-bs-theme") || "light");

  document.getElementById("theme-toggle").addEventListener("click", () => {
    setTheme(document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark");
  });
  document.getElementById("logout").addEventListener("click", onLogout);
  document.getElementById("global-search").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = document.getElementById("global-q").value.trim();
    if (q) navigate("/people", { q });
  });
  document.getElementById("sidebar").addEventListener("click", (e) => {
    if (e.target.closest("a.nav-link")) Offcanvas.getInstance(document.getElementById("sidebar"))?.hide();
  });

  return { view: document.getElementById("view") };
}
