import { html } from "../lib/dom.js";
import { num } from "../lib/format.js";

/** Pager markup. Buttons carry data-page; wire with `onPage`. */
export function pager({ total, limit, offset, noun = "results" }) {
  if (!total) return html``;
  const pages = Math.max(1, Math.ceil(total / limit));
  const page = Math.floor(offset / limit) + 1;
  const from = offset + 1;
  const to = Math.min(total, offset + limit);

  const window = new Set([1, pages, page - 1, page, page + 1]);
  const items = [...window].filter((p) => p >= 1 && p <= pages).sort((a, b) => a - b);
  const buttons = [];
  items.forEach((p, i) => {
    if (i > 0 && p - items[i - 1] > 1) buttons.push(html`<li class="page-item disabled"><span class="page-link">&hellip;</span></li>`);
    buttons.push(html`<li class="page-item ${p === page ? "active" : ""}"><button type="button" class="page-link" data-page="${p}" ${p === page ? 'aria-current="page"' : ""}>${p}</button></li>`);
  });

  return html`<div class="pager">
    <span>Showing ${num(from)} to ${num(to)} of ${num(total)} ${noun}</span>
    ${pages > 1
      ? html`<nav aria-label="Pages"><ul class="pagination pagination-sm mb-0">
          <li class="page-item ${page === 1 ? "disabled" : ""}"><button type="button" class="page-link" data-page="${page - 1}">Previous</button></li>
          ${buttons}
          <li class="page-item ${page === pages ? "disabled" : ""}"><button type="button" class="page-link" data-page="${page + 1}">Next</button></li>
        </ul></nav>`
      : ""}
  </div>`;
}

export function bindPager(root, onPage) {
  root.addEventListener("click", (e) => {
    const b = e.target instanceof Element ? e.target.closest("[data-page]") : null;
    if (b && !b.closest(".disabled")) onPage(Number(b.dataset.page));
  });
}
