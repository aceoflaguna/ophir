import { html } from "../lib/dom.js";
import { date, initials, relTime } from "../lib/format.js";

/* ---------------------------------------------------------------- status lamps */

export const state = (cls, label, { pulse = false, title = "" } = {}) =>
  html`<span class="state ${cls}" title="${title}"><span class="lamp ${pulse ? "pulse" : ""}" aria-hidden="true"></span>${label}</span>`;

/** Account standing: active / suspended / banned. */
export function standing(account, { detail = false } = {}) {
  const { status, reason, until } = account;
  if (status === "banned") return state("s-stop", "Banned", { title: reason ?? "" });
  if (status === "suspended") {
    const when = until ? `until ${date(until)}` : "indefinitely";
    return html`${state("s-hold", "Suspended", { title: [reason, when].filter(Boolean).join(". ") })}${detail ? html`<div class="cell-sub">${when}</div>` : ""}`;
  }
  return state("s-go", "Active");
}

export function driverState(status) {
  if (status === "online") return state("s-go", "Online", { pulse: true });
  if (status === "busy") return state("s-route", "On a trip");
  return state("s-idle", "Offline");
}

const RIDE_STATES = {
  searching: ["s-hold", "Searching", true],
  accepted: ["s-route", "Driver assigned", false],
  arrived: ["s-route", "Driver arrived", false],
  in_progress: ["s-route", "In progress", true],
  completed: ["s-go", "Completed", false],
  cancelled: ["s-stop", "Cancelled", false],
  no_drivers: ["s-idle", "No drivers found", false],
};
export function rideState(status) {
  const [cls, label, pulse] = RIDE_STATES[status] ?? ["s-idle", status, false];
  return state(cls, label, { pulse });
}

/* ------------------------------------------------------------------- bits */

export const plate = (p) => (p ? html`<span class="plate">${p}</span>` : "");

export function avatar(name, large = false) {
  let h = 0;
  for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return html`<span class="avatar ${large ? "avatar-lg" : ""}" style="--h:${h}" aria-hidden="true">${initials(name)}</span>`;
}

export const roleTag = (role) => html`<span class="role-tag">${role === "driver" ? "Driver" : "Rider"}</span>`;

export function rating(r) {
  if (!r || r.count === 0) return html`<span class="text-body-secondary">No ratings</span>`;
  return html`<span class="num">${Number(r.average).toFixed(2)}</span> <span class="cell-sub">(${r.count})</span>`;
}

/* ----------------------------------------------------------- feedback states */

export function errorBox(err) {
  return html`<div class="alert alert-danger d-flex flex-wrap align-items-center justify-content-between gap-2 m-3" role="alert">
    <div><i class="bi bi-exclamation-triangle me-2"></i>${err?.message ?? "Something went wrong."}</div>
    <button type="button" class="btn btn-sm btn-outline-secondary" data-retry>Try again</button>
  </div>`;
}

export function emptyState({ icon = "bi-inbox", title, text = "", action = "" }) {
  return html`<div class="empty-state"><i class="bi ${icon}"></i><div class="h5 m-0">${title}</div>${text ? html`<div class="text-body-secondary">${text}</div>` : ""}${action}</div>`;
}

export function skeletonRows(cols, rows = 6) {
  const widths = ["9rem", "6rem", "7rem", "5rem", "4rem", "6rem", "5rem"];
  return html`<div class="table-responsive"><table class="table"><tbody>
    ${Array.from({ length: rows }, () => html`<tr>${Array.from({ length: cols }, (_, i) => html`<td><span class="skeleton-line" style="--w:${widths[i % widths.length]}"></span></td>`)}</tr>`)}
  </tbody></table></div>`;
}

export const skeletonPanel = (lines = 4) =>
  html`<div class="panel-body">${Array.from({ length: lines }, (_, i) => html`<div class="mb-2"><span class="skeleton-line" style="--w:${60 + ((i * 17) % 35)}%"></span></div>`)}</div>`;

/* -------------------------------------------------------------- moderation */

/** Buttons for the moderation actions that make sense for the account's current standing. */
export function moderationButtons(status, { size = "" } = {}) {
  const sm = size ? ` btn-${size}` : "";
  const out = [];
  if (status !== "banned") {
    out.push(html`<button type="button" class="btn btn-outline-secondary${sm}" data-mod="suspend"><i class="bi bi-pause-circle me-1"></i>${status === "suspended" ? "Change suspension" : "Suspend"}</button>`);
    out.push(html`<button type="button" class="btn btn-outline-danger${sm}" data-mod="ban"><i class="bi bi-slash-circle me-1"></i>Ban</button>`);
  }
  if (status !== "active") {
    out.push(html`<button type="button" class="btn btn-success${sm}" data-mod="reinstate"><i class="bi bi-arrow-counterclockwise me-1"></i>Reinstate</button>`);
  }
  return out;
}

export const lastSeen = (d) => (d ? `Seen ${relTime(d)}` : "Never seen");
