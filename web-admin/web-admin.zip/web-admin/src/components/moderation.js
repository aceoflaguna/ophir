import { Modal } from "bootstrap";
import { api } from "../lib/api.js";
import { html, esc } from "../lib/dom.js";
import { plural } from "../lib/format.js";
import { toast } from "./toast.js";

const PRESETS = {
  suspend: ["Safety complaint", "Harassment report", "Repeated cancellations", "Documents under review"],
  ban: ["Fraud", "Safety violation", "Fake identity", "Repeated violations"],
  reinstate: ["Reviewed and cleared", "Suspension served", "Applied by mistake"],
};

const DURATIONS = [
  ["", "Until I lift it"],
  ["24h", "24 hours"],
  ["3d", "3 days"],
  ["7d", "7 days"],
  ["30d", "30 days"],
  ["custom", "Pick a date and time"],
];
const MS = { "24h": 86400e3, "3d": 3 * 86400e3, "7d": 7 * 86400e3, "30d": 30 * 86400e3 };

const localInputValue = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

function copyFor(action, user) {
  const first = user.fullName.split(" ")[0];
  const driver = user.role === "driver";
  if (action === "suspend") {
    return {
      title: user.account.status === "suspended" ? `Change suspension for ${user.fullName}` : `Suspend ${user.fullName}`,
      lead: driver
        ? `${first} can still sign in but can't go online or accept rides. A ride they accepted but haven't started goes back to the queue for another driver.`
        : `${first} can still sign in but can't request rides. A ride they're waiting for is cancelled.`,
      cta: user.account.status === "suspended" ? "Update suspension" : `Suspend ${driver ? "driver" : "rider"}`,
      btn: "btn-warning",
      done: "suspended",
    };
  }
  if (action === "ban") {
    return {
      title: `Ban ${user.fullName}`,
      lead: `Blocks sign-in and signs ${first} out of every device right away. ${driver ? "They're taken offline and any accepted ride goes back to the queue." : "Any ride they're waiting for is cancelled."} You can reinstate the account later.`,
      cta: `Ban ${driver ? "driver" : "rider"}`,
      btn: "btn-danger",
      done: "banned",
    };
  }
  return {
    title: `Reinstate ${user.fullName}`,
    lead: driver ? `Restores access. ${first} will need to go online again to receive rides.` : `Restores access so ${first} can request rides again.`,
    cta: "Reinstate account",
    btn: "btn-success",
    done: "reinstated",
  };
}

/**
 * Open the suspend / ban / reinstate dialog for a user ({ id, fullName, role, account: { status } }).
 * `onDone(result)` runs after the server accepted the change.
 */
export function openModeration({ action, user, onDone }) {
  const c = copyFor(action, user);
  const el = document.createElement("div");
  el.className = "modal fade";
  el.tabIndex = -1;
  el.setAttribute("aria-labelledby", "mod-title");
  el.innerHTML = html`
    <div class="modal-dialog modal-dialog-centered">
      <form class="modal-content" novalidate>
        <div class="modal-header">
          <h2 class="modal-title h5" id="mod-title">${c.title}</h2>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="mb-3">${c.lead}</p>
          <div id="mod-error" class="alert alert-danger d-none" role="alert"></div>
          <div id="mod-force" class="alert alert-warning d-none" role="alert">
            <div class="mb-2"><strong>A trip is in progress.</strong> <a id="mod-ride-link" href="#" target="_self">View the ride</a>. Waiting for it to finish is the safest option.</div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="mod-force-check">
              <label class="form-check-label" for="mod-force-check">Cancel the trip in progress and continue</label>
            </div>
          </div>

          <div class="mb-3">
            <label for="mod-reason" class="form-label">${action === "reinstate" ? "Note (optional)" : "Reason"}</label>
            <textarea id="mod-reason" class="form-control" rows="3" maxlength="500" ${action === "reinstate" ? "" : "required"} placeholder="${action === "reinstate" ? "Why is the account being reinstated?" : "What happened? This is saved in the account history."}"></textarea>
            <div class="invalid-feedback" data-error="reason">Enter a reason of at least 3 characters.</div>
            <div class="d-flex flex-wrap gap-1 mt-2">${PRESETS[action].map((p) => html`<button type="button" class="chip-btn" data-preset="${p}">${p}</button>`)}</div>
          </div>

          ${action === "suspend" ? html`<div class="mb-3">
            <label for="mod-duration" class="form-label">How long</label>
            <select id="mod-duration" class="form-select">${DURATIONS.map(([v, l]) => html`<option value="${v}">${l}</option>`)}</select>
            <input type="datetime-local" id="mod-until" class="form-control mt-2 d-none" min="${localInputValue(new Date(Date.now() + 60000))}" aria-label="Suspension end">
            <div class="invalid-feedback" data-error="until">Pick a time in the future.</div>
            <div class="form-text">The account is reinstated automatically when the time is up.</div>
          </div>` : ""}

          ${action === "ban" ? html`<div class="form-check">
            <input class="form-check-input" type="checkbox" id="mod-ack" required>
            <label class="form-check-label" for="mod-ack">I understand this takes effect immediately.</label>
            <div class="invalid-feedback" data-error="ack">Confirm to continue.</div>
          </div>` : ""}
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn ${c.btn}" id="mod-submit"><span class="spinner-border spinner-border-sm me-2 d-none" aria-hidden="true"></span>${c.cta}</button>
        </div>
      </form>
    </div>`.toString();
  document.body.append(el);

  const modal = new Modal(el);
  el.addEventListener("hidden.bs.modal", () => {
    modal.dispose();
    el.remove();
  });
  el.addEventListener("shown.bs.modal", () => el.querySelector("#mod-reason")?.focus());

  const $ = (s) => el.querySelector(s);
  const form = $("form");
  const reason = $("#mod-reason");
  const submit = $("#mod-submit");
  let needsForce = false;

  const setInvalid = (key, on) => {
    const field = { reason, until: $("#mod-until"), ack: $("#mod-ack") }[key];
    field?.classList.toggle("is-invalid", on);
    const msg = $(`[data-error="${key}"]`);
    if (msg && key !== "reason") msg.style.display = on ? "block" : "";
    if (msg && key === "reason") msg.style.display = on ? "block" : "";
  };
  const showError = (message) => {
    const box = $("#mod-error");
    box.textContent = message;
    box.classList.remove("d-none");
  };
  const busy = (on) => {
    submit.disabled = on;
    $("#mod-submit .spinner-border").classList.toggle("d-none", !on);
  };

  el.addEventListener("click", (e) => {
    const chip = e.target.closest("[data-preset]");
    if (chip) {
      reason.value = chip.getAttribute("data-preset");
      setInvalid("reason", false);
      reason.focus();
    }
  });
  $("#mod-duration")?.addEventListener("change", (e) => {
    const custom = e.target.value === "custom";
    $("#mod-until").classList.toggle("d-none", !custom);
    if (custom && !$("#mod-until").value) $("#mod-until").value = localInputValue(new Date(Date.now() + 86400e3));
    setInvalid("until", false);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    $("#mod-error").classList.add("d-none");
    const text = reason.value.trim();
    let bad = false;

    if (action !== "reinstate" && text.length < 3) { setInvalid("reason", true); bad = true; } else setInvalid("reason", false);
    let until;
    if (action === "suspend") {
      const dur = $("#mod-duration").value;
      if (dur === "custom") {
        const v = $("#mod-until").value;
        const d = v ? new Date(v) : null;
        if (!d || Number.isNaN(d.getTime()) || d.getTime() <= Date.now()) { setInvalid("until", true); bad = true; } else { setInvalid("until", false); until = d.toISOString(); }
      } else if (dur) until = new Date(Date.now() + MS[dur]).toISOString();
    }
    if (action === "ban" && !$("#mod-ack").checked) { setInvalid("ack", true); bad = true; } else if (action === "ban") setInvalid("ack", false);
    if (needsForce && !$("#mod-force-check").checked) { $("#mod-force").classList.add("border-danger"); bad = true; }
    if (bad) return;

    const body = action === "reinstate" ? { note: text || undefined } : { reason: text, force: needsForce && $("#mod-force-check").checked };
    if (action === "suspend" && until) body.until = until;

    busy(true);
    try {
      const res = await api.post(`/admin/users/${user.id}/${action}`, body);
      modal.hide();
      const rides = res.affectedRides ?? [];
      const requeued = rides.filter((r) => r.outcome === "requeued").length;
      const cancelled = rides.filter((r) => r.outcome === "cancelled").length;
      const extra = [requeued && `${plural(requeued, "ride")} sent back to the queue`, cancelled && `${plural(cancelled, "ride")} cancelled`].filter(Boolean).join(", ");
      toast(`${user.fullName} ${c.done}${extra ? `. ${extra}.` : "."}`);
      onDone?.(res);
    } catch (err) {
      if (err.code === "RIDE_IN_PROGRESS") {
        needsForce = true;
        const link = $("#mod-ride-link");
        link.setAttribute("href", `#/rides/${err.details?.rideId ?? ""}`);
        link.addEventListener("click", () => modal.hide(), { once: true });
        $("#mod-force").classList.remove("d-none", "border-danger");
      } else if (err.status === 400 && Array.isArray(err.details)) {
        for (const d of err.details) if (d.path === "reason" || d.path === "until") setInvalid(d.path, true);
        showError(err.message);
      } else {
        showError(err.message);
      }
    } finally {
      busy(false);
    }
  });

  modal.show();
  return modal;
}

