import { Toast } from "bootstrap";
import { esc } from "../lib/dom.js";

/** kind: success | danger | warning | info */
export function toast(message, kind = "success") {
  let box = document.getElementById("toasts");
  if (!box) {
    box = document.createElement("div");
    box.id = "toasts";
    box.className = "toast-container position-fixed bottom-0 end-0 p-3";
    document.body.append(box);
  }
  const icon = { success: "bi-check-circle-fill", danger: "bi-x-octagon-fill", warning: "bi-exclamation-triangle-fill", info: "bi-info-circle-fill" }[kind] ?? "bi-info-circle-fill";
  const el = document.createElement("div");
  el.className = `toast align-items-center text-bg-${kind} border-0`;
  el.setAttribute("role", kind === "danger" ? "alert" : "status");
  el.innerHTML = `<div class="d-flex"><div class="toast-body"><i class="bi ${icon} me-2"></i>${esc(message)}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
  box.append(el);
  const t = new Toast(el, { delay: kind === "danger" ? 8000 : 4500 });
  el.addEventListener("hidden.bs.toast", () => el.remove());
  t.show();
}
