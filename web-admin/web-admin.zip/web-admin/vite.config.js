import { defineConfig, loadEnv } from "vite";

// In dev and preview, /api is proxied to the API server so the browser stays same-origin (no CORS setup needed).
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const target = env.API_PROXY_TARGET || "http://localhost:3000";
  const proxy = { "/api": { target, changeOrigin: true } };
  return {
    server: { port: 5173, proxy },
    preview: { port: 4173, proxy },
    build: { target: "es2020", sourcemap: false, chunkSizeWarningLimit: 800 },
  };
});
