import { afterAll, beforeAll, describe, expect, test } from "@jest/globals";
import { runHousekeeping } from "../../src/modules/housekeeping/housekeeping.service.ts";
import { api, DROPOFF, makeDriver, offline, pendingOffer, PICKUP, query, signup, startE2E, until } from "../support/e2e.ts";

let stop: () => Promise<void>;
let admin: { id: string; token: string; email: string };

async function makeAdmin() {
  const u = await signup("rider");
  await query("UPDATE users SET role='admin' WHERE id=$1", [u.id]);
  const login = await api("post", "/auth/login", { body: { email: u.email, password: "Passw0rdX" } }); // new token carries the admin role
  return { id: u.id, email: u.email, token: login.body.tokens.accessToken as string };
}

beforeAll(async () => {
  stop = await startE2E();
  admin = await makeAdmin();
});
afterAll(async () => { await stop(); });

const A = (method: "get" | "post", path: string, body?: object) => api(method, `/admin${path}`, body ? { token: admin.token, body } : { token: admin.token });
const suspend = (id: string, body: object = {}) => A("post", `/users/${id}/suspend`, { reason: "Repeated complaints", ...body });
const ban = (id: string, body: object = {}) => A("post", `/users/${id}/ban`, { reason: "Fraud", ...body });
const reinstate = (id: string, note?: string) => A("post", `/users/${id}/reinstate`, note ? { note } : {});
const driverStatus = async (d: { token: string }) => (await api("get", "/drivers/me", { token: d.token })).body.driver.status;
const book = (token: string) => api("post", "/rides", { token, body: { pickup: PICKUP, dropoff: DROPOFF } });

describe("access control", () => {
  test("only admins can use the admin API", async () => {
    const rider = await signup("rider");
    for (const path of ["/stats", "/users", "/rides"]) expect((await api("get", `/admin${path}`, { token: rider.token })).status).toBe(403);
    expect((await api("post", `/admin/users/${rider.id}/suspend`, { token: rider.token, body: { reason: "x y z" } })).status).toBe(403);
    expect((await api("get", "/admin/users")).status).toBe(401);
  });

  test("validation: reason required, ids must be UUIDs, `until` must be a future ISO date", async () => {
    const rider = await signup("rider");
    expect((await A("post", `/users/${rider.id}/suspend`, {})).status).toBe(400);
    expect((await A("post", `/users/${rider.id}/suspend`, { reason: "ab" })).status).toBe(400);
    expect((await A("post", `/users/not-a-uuid/ban`, { reason: "Fraud" })).status).toBe(400);
    expect((await suspend(rider.id, { until: "yesterday" })).status).toBe(400);
    expect((await suspend(rider.id, { until: new Date(Date.now() - 3600_000).toISOString() })).status).toBe(400);
    expect((await A("post", `/users/00000000-0000-4000-8000-000000000000/ban`, { reason: "Fraud" })).status).toBe(404);
  });

  test("admins cannot be moderated and cannot moderate themselves", async () => {
    const other = await makeAdmin();
    expect((await ban(other.id)).body.error.code).toBe("FORBIDDEN");
    expect((await ban(admin.id)).status).toBe(400);
  });
});

describe("directory", () => {
  test("lists riders and drivers (never admins) with filters, search and paging", async () => {
    const rider = await signup("rider");
    const driver = await makeDriver(14.5548, 121.0245);
    await suspend(rider.id);

    const all = await A("get", "/users?limit=100");
    expect(all.status).toBe(200);
    expect(all.body.items.some((u: any) => u.role === "admin")).toBe(false);
    expect(all.body.total).toBeGreaterThanOrEqual(2);

    const drivers = await A("get", "/users?role=driver&limit=100");
    expect(drivers.body.items.every((u: any) => u.role === "driver")).toBe(true);
    const me = drivers.body.items.find((u: any) => u.id === driver.id);
    expect(me.driver).toMatchObject({ status: "online", vehicle: { make: "Toyota", model: "Vios" } });
    expect(me.driver.location).toMatchObject({ lat: 14.5548, lng: 121.0245 });

    const suspended = await A("get", "/users?status=suspended");
    expect(suspended.body.items.map((u: any) => u.id)).toContain(rider.id);
    expect(suspended.body.items.every((u: any) => u.account.status === "suspended")).toBe(true);

    expect((await A("get", `/users?q=${encodeURIComponent(rider.email)}`)).body.items.map((u: any) => u.id)).toEqual([rider.id]);
    expect((await A("get", `/users?q=${rider.id}`)).body.items.map((u: any) => u.id)).toEqual([rider.id]);
    expect((await A("get", "/users?q=%25")).body.total).toBe(0); // '%' is escaped, not a wildcard
    expect((await A("get", "/users?driverStatus=online&role=driver")).body.items.map((u: any) => u.id)).toContain(driver.id);

    const page1 = await A("get", "/users?limit=1&offset=0&sort=oldest");
    const page2 = await A("get", "/users?limit=1&offset=1&sort=oldest");
    expect(page1.body.items).toHaveLength(1);
    expect(page1.body.items[0].id).not.toBe(page2.body.items[0].id);
    expect(page1.body.total).toBe(page2.body.total);
    await offline(driver);
  });

  test("user detail: profile, vehicle, stats, sessions, recent rides and (empty) moderation history", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    const d = await A("get", `/users/${driver.id}`);
    expect(d.status).toBe(200);
    expect(d.body.user).toMatchObject({ id: driver.id, role: "driver", account: { status: "active", reason: null }, rating: { average: 5, count: 0 } });
    expect(d.body.driver).toMatchObject({ status: "online", licenseNumber: expect.any(String), vehicle: { plate: expect.any(String) } });
    expect(d.body.driver.location).toMatchObject({ lat: 14.5548 });
    expect(d.body.stats).toMatchObject({ totalRides: 0, completed: 0, offers: { total: 0 } });
    expect(d.body.activeSessions).toBe(1);
    expect(d.body.moderation).toEqual([]);
    expect((await A("get", `/users/${admin.id}`)).status).toBe(404); // admins are not listed
    await offline(driver);
  });
});

describe("suspension", () => {
  test("suspended driver is forced offline, cannot work, but can still sign in and see why", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    const rider = await signup("rider");
    expect(await driverStatus(driver)).toBe("online");

    const r = await suspend(driver.id, { reason: "Rude to riders" });
    expect(r.status).toBe(200);
    expect(r.body.account).toMatchObject({ status: "suspended", reason: "Rude to riders", until: null });
    expect(await driverStatus(driver)).toBe("offline");

    // no longer discoverable / matchable
    const est = await api("post", "/rides/estimate", { token: rider.token, body: { pickup: PICKUP, dropoff: DROPOFF } });
    expect(est.body.options.find((o: any) => o.vehicleType === "economy").nearbyDrivers).toBe(0);

    // blocked from operating, with a machine-readable reason
    const online = await api("post", "/drivers/me/online", { token: driver.token, body: { lat: 14.5548, lng: 121.0245 } });
    expect(online.status).toBe(403);
    expect(online.body.error).toMatchObject({ code: "ACCOUNT_SUSPENDED", details: { reason: "Rude to riders" } });
    expect((await api("put", "/drivers/me/location", { token: driver.token, body: { lat: 14.5, lng: 121 } })).body.error.code).toBe("ACCOUNT_SUSPENDED");

    // can still log in; the app learns the status from the profile
    const login = await api("post", "/auth/login", { body: { email: driver.email, password: "Passw0rdX" } });
    expect(login.status).toBe(200);
    expect(login.body.user.account).toMatchObject({ status: "suspended", reason: "Rude to riders" });
    expect((await api("get", "/users/me", { token: driver.token })).body.user.account.status).toBe("suspended");

    // audit trail
    const hist = (await A("get", `/users/${driver.id}`)).body;
    expect(hist.user.account).toMatchObject({ status: "suspended", changedBy: { id: admin.id } });
    expect(hist.moderation[0]).toMatchObject({ action: "suspend", previousStatus: "active", newStatus: "suspended", reason: "Rude to riders", admin: { id: admin.id } });

    // reinstate -> can work again (they must go online themselves)
    expect((await reinstate(driver.id, "Apologised")).body.account.status).toBe("active");
    expect(await driverStatus(driver)).toBe("offline");
    expect((await api("post", "/drivers/me/online", { token: driver.token, body: { lat: 14.5548, lng: 121.0245 } })).status).toBe(200);
    const after = (await A("get", `/users/${driver.id}`)).body;
    expect(after.user.account).toMatchObject({ status: "active", reason: null });
    expect(after.moderation.map((m: any) => m.action)).toEqual(["reinstate", "suspend"]);
    expect(after.moderation[0].reason).toBe("Apologised");
    expect((await reinstate(driver.id)).body.error.code).toBe("INVALID_STATE"); // already active
    await offline(driver);
  });

  test("suspended rider cannot book but can sign in; reinstating restores booking", async () => {
    const rider = await signup("rider");
    await suspend(rider.id);
    const r = await book(rider.token);
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe("ACCOUNT_SUSPENDED");
    expect((await api("post", "/auth/login", { body: { email: rider.email, password: "Passw0rdX" } })).status).toBe(200);
    await reinstate(rider.id);
    const ok = await book(rider.token);
    expect(ok.status).toBe(201);
    await api("post", `/rides/${ok.body.ride.id}/cancel`, { token: rider.token });
  });

  test("suspended drivers are skipped by matching", async () => {
    const bad = await makeDriver(14.5548, 121.0245); // nearest
    const good = await makeDriver(14.56, 121.03);
    const rider = await signup("rider");
    // suspend "bad" in the DB only (no side effects) to prove the matcher itself checks standing, not just the geo index
    await query("UPDATE users SET account_status='suspended' WHERE id=$1", [bad.id]);
    const req = await book(rider.token);
    expect((await until(pendingOffer(good))).ride.id).toBe(req.body.ride.id);
    expect((await api("get", "/drivers/me/offers", { token: bad.token })).body.offers).toHaveLength(0);
    await api("post", `/rides/${req.body.ride.id}/cancel`, { token: rider.token });
    await query("UPDATE users SET account_status='active' WHERE id=$1", [bad.id]);
    await Promise.all([offline(bad), offline(good)]);
  });

  test("a timed suspension is lifted by housekeeping (audited as auto_reinstate) once it expires", async () => {
    const driver = await signup("driver");
    const until = new Date(Date.now() + 3600_000).toISOString();
    const r = await suspend(driver.id, { until });
    expect(new Date(r.body.account.until).toISOString()).toBe(until);

    expect(await runHousekeeping("lift-expired-suspensions")).toBe(0); // not yet
    await query("UPDATE users SET suspended_until = now() - interval '1 minute' WHERE id=$1", [driver.id]);
    expect(await runHousekeeping("lift-expired-suspensions")).toBe(1);

    const d = (await A("get", `/users/${driver.id}`)).body;
    expect(d.user.account).toMatchObject({ status: "active", reason: null, until: null });
    expect(d.moderation[0]).toMatchObject({ action: "auto_reinstate", admin: null, newStatus: "active" });
  });

  test("an expired suspension is also lifted on the spot when the user tries to work (no need to wait for the job)", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    await suspend(driver.id, { until: new Date(Date.now() + 3600_000).toISOString() });
    await query("UPDATE users SET suspended_until = now() - interval '1 second' WHERE id=$1", [driver.id]);
    expect((await api("post", "/drivers/me/online", { token: driver.token, body: { lat: 14.5548, lng: 121.0245 } })).status).toBe(200);
    expect((await A("get", `/users/${driver.id}`)).body.user.account.status).toBe("active");
    await offline(driver);
  });

  test("suspending an already-suspended account updates the reason/end date", async () => {
    const rider = await signup("rider");
    await suspend(rider.id, { reason: "First reason" });
    const again = await suspend(rider.id, { reason: "Second reason", until: new Date(Date.now() + 86400_000).toISOString() });
    expect(again.body.account).toMatchObject({ status: "suspended", reason: "Second reason" });
    expect((await A("get", `/users/${rider.id}`)).body.moderation).toHaveLength(2);
  });
});

describe("ban", () => {
  test("banned user cannot sign in, loses all sessions immediately and cannot refresh", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    const second = await api("post", "/auth/login", { body: { email: driver.email, password: "Passw0rdX" } });
    expect((await ban(driver.id, { reason: "Fraudulent documents" })).body.account.status).toBe("banned");

    expect(await (async () => (await A("get", `/users/${driver.id}`)).body.driver.status)()).toBe("offline");
    // access tokens die immediately (both sessions)
    expect((await api("get", "/users/me", { token: driver.token })).body.error.code).toBe("SESSION_REVOKED");
    expect((await api("get", "/users/me", { token: second.body.tokens.accessToken })).body.error.code).toBe("SESSION_REVOKED");
    // refresh and login are refused with an explicit code (not "token reuse")
    const refresh = await api("post", "/auth/refresh", { body: { refreshToken: driver.refresh } });
    expect(refresh.status).toBe(401);
    expect(refresh.body.error.code).toBe("ACCOUNT_BANNED");
    const login = await api("post", "/auth/login", { body: { email: driver.email, password: "Passw0rdX" } });
    expect(login.status).toBe(403);
    expect(login.body.error).toMatchObject({ code: "ACCOUNT_BANNED", details: { reason: "Fraudulent documents" } });
    // wrong password must still look like any other failed login (no status leak)
    expect((await api("post", "/auth/login", { body: { email: driver.email, password: "WrongPass123" } })).body.error.code).toBe("INVALID_CREDENTIALS");

    // state machine
    expect((await ban(driver.id)).body.error.code).toBe("INVALID_STATE");
    expect((await suspend(driver.id)).body.error.code).toBe("INVALID_STATE");

    // reinstated users can sign in again
    expect((await reinstate(driver.id)).status).toBe(200);
    expect((await api("post", "/auth/login", { body: { email: driver.email, password: "Passw0rdX" } })).status).toBe(200);
  });

  test("banning a rider cancels their live search and the admin API still shows why", async () => {
    const rider = await signup("rider");
    const req = await book(rider.token);
    const r = await ban(rider.id);
    expect(r.body.affectedRides).toEqual([{ rideId: req.body.ride.id, outcome: "cancelled" }]);

    const ride = (await A("get", `/rides/${req.body.ride.id}`)).body;
    expect(ride.ride).toMatchObject({ status: "cancelled", cancellation: { by: "system", reason: expect.stringContaining("banned") } });
    expect(ride.events.map((e: any) => e.type)).toEqual(["requested", "cancelled"]);
    expect(ride.events[1].actor).toMatchObject({ id: admin.id });
    expect(ride.rider.accountStatus).toBe("banned");
  });
});

describe("moderating people on live rides", () => {
  test("suspending a driver who already accepted a ride puts the ride back in the queue for another driver", async () => {
    const a = await makeDriver(14.5548, 121.0245);
    const b = await makeDriver(14.56, 121.03);
    const rider = await signup("rider");
    const req = await book(rider.token);
    const offer = await until(pendingOffer(a));
    expect((await api("post", `/drivers/me/offers/${offer.offerId}/accept`, { token: a.token })).status).toBe(200);

    const r = await suspend(a.id);
    expect(r.body.affectedRides).toEqual([{ rideId: req.body.ride.id, outcome: "requeued" }]);
    expect(await driverStatus(a)).toBe("offline"); // not returned to the pool

    expect((await until(pendingOffer(b))).ride.id).toBe(req.body.ride.id);
    const view = (await api("get", `/rides/${req.body.ride.id}`, { token: rider.token })).body.ride;
    expect(view).toMatchObject({ status: "searching", driverId: null });
    const events = (await A("get", `/rides/${req.body.ride.id}`)).body.events.map((e: any) => e.type);
    expect(events).toEqual(expect.arrayContaining(["accepted", "driver_removed", "offered"]));

    await api("post", `/rides/${req.body.ride.id}/cancel`, { token: rider.token });
    await Promise.all([offline(a), offline(b)]);
  });

  test("a pending offer to a driver who is then suspended is withdrawn and re-offered", async () => {
    const a = await makeDriver(14.5548, 121.0245);
    const b = await makeDriver(14.56, 121.03);
    const rider = await signup("rider");
    const req = await book(rider.token);
    await until(pendingOffer(a));
    await suspend(a.id);
    expect((await api("get", "/drivers/me/offers", { token: a.token })).body.offers).toHaveLength(0);
    expect((await until(pendingOffer(b))).ride.id).toBe(req.body.ride.id);
    await api("post", `/rides/${req.body.ride.id}/cancel`, { token: rider.token });
    await Promise.all([offline(a), offline(b)]);
  });

  test("a trip in progress is never abandoned silently: 409 unless force=true", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    const rider = await signup("rider");
    const req = await book(rider.token);
    const offer = await until(pendingOffer(driver));
    await api("post", `/drivers/me/offers/${offer.offerId}/accept`, { token: driver.token });
    await api("post", `/rides/${req.body.ride.id}/arrive`, { token: driver.token });
    await api("post", `/rides/${req.body.ride.id}/start`, { token: driver.token });

    const refused = await suspend(driver.id);
    expect(refused.status).toBe(409);
    expect(refused.body.error).toMatchObject({ code: "RIDE_IN_PROGRESS", details: { rideId: req.body.ride.id } });
    expect((await A("get", `/users/${driver.id}`)).body.user.account.status).toBe("active"); // nothing changed
    expect((await refused.body.error.details.rideId)).toBe(req.body.ride.id);

    const forced = await suspend(driver.id, { force: true });
    expect(forced.status).toBe(200);
    expect(forced.body.affectedRides).toEqual([{ rideId: req.body.ride.id, outcome: "cancelled" }]);
    expect((await api("get", `/rides/${req.body.ride.id}`, { token: rider.token })).body.ride).toMatchObject({ status: "cancelled", cancellation: { by: "system" } });
    expect(await driverStatus(driver)).toBe("offline");
    // the rider is free to book again
    const again = await book(rider.token);
    expect(again.status).toBe(201);
    await api("post", `/rides/${again.body.ride.id}/cancel`, { token: rider.token });
  });

  test("banning a rider whose driver already accepted cancels the ride and frees the driver", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    const rider = await signup("rider");
    const req = await book(rider.token);
    const offer = await until(pendingOffer(driver));
    await api("post", `/drivers/me/offers/${offer.offerId}/accept`, { token: driver.token });
    expect((await ban(rider.id)).status).toBe(200); // accepted (not yet in progress) -> cancelled without force
    expect((await A("get", `/rides/${req.body.ride.id}`)).body.ride.status).toBe("cancelled");
    expect(await driverStatus(driver)).toBe("online");
    await offline(driver);
  });
});

describe("rides + dashboard", () => {
  test("ride directory: filters, search, paging; detail has parties, events, offers and payment", async () => {
    const driver = await makeDriver(14.5548, 121.0245);
    const rider = await signup("rider");
    const req = await book(rider.token);
    const offer = await until(pendingOffer(driver));
    await api("post", `/drivers/me/offers/${offer.offerId}/accept`, { token: driver.token });

    const live = await A("get", "/rides?status=active&limit=100");
    expect(live.body.items.map((r: any) => r.id)).toContain(req.body.ride.id);
    expect(live.body.items.find((r: any) => r.id === req.body.ride.id)).toMatchObject({ status: "accepted", rider: { id: rider.id }, driver: { id: driver.id }, currency: "USD" });
    expect((await A("get", `/rides?userId=${rider.id}`)).body.total).toBe(1);
    expect((await A("get", `/rides?q=${req.body.ride.id}`)).body.items).toHaveLength(1);
    expect((await A("get", "/rides?status=completed&limit=100")).body.items.map((r: any) => r.id)).not.toContain(req.body.ride.id);
    expect((await A("get", "/rides?status=bogus")).status).toBe(400);

    await api("post", `/rides/${req.body.ride.id}/arrive`, { token: driver.token });
    await api("post", `/rides/${req.body.ride.id}/start`, { token: driver.token });
    await api("post", `/rides/${req.body.ride.id}/complete`, { token: driver.token, body: {} });

    const detail = (await A("get", `/rides/${req.body.ride.id}`)).body;
    expect(detail.ride).toMatchObject({ status: "completed", final: { fare: expect.any(Number) } });
    expect(detail.rider).toMatchObject({ id: rider.id, email: rider.email });
    expect(detail.driver).toMatchObject({ id: driver.id, vehicle: { make: "Toyota" } });
    expect(detail.events.map((e: any) => e.type)).toEqual(["requested", "offered", "accepted", "arrived", "started", "completed"]);
    expect(detail.offers).toHaveLength(1);
    expect(detail.offers[0]).toMatchObject({ status: "accepted", driver: { id: driver.id } });
    expect(detail.payment).toMatchObject({ status: "paid", amount: detail.ride.final.fare });
    expect((await A("get", "/rides/00000000-0000-4000-8000-000000000000")).status).toBe(404);

    // user detail reflects the finished trip
    const rd = (await A("get", `/users/${rider.id}`)).body;
    expect(rd.stats).toMatchObject({ totalRides: 1, completed: 1, gross: detail.ride.final.fare });
    expect(rd.recentRides[0].id).toBe(req.body.ride.id);
    const dd = (await A("get", `/users/${driver.id}`)).body;
    expect(dd.stats).toMatchObject({ completed: 1, earnings: detail.ride.final.driverEarnings, offers: { total: 1, accepted: 1 } });
    await offline(driver);
  });

  test("dashboard numbers", async () => {
    const s = (await A("get", "/stats")).body;
    expect(s.riders).toMatchObject({ total: expect.any(Number), active: expect.any(Number), suspended: expect.any(Number), banned: expect.any(Number) });
    expect(s.riders.total).toBe(s.riders.active + s.riders.suspended + s.riders.banned);
    expect(s.drivers).toMatchObject({ online: expect.any(Number), busy: expect.any(Number), offline: expect.any(Number) });
    expect(s.rides.completed).toBeGreaterThanOrEqual(1);
    expect(s.today.completed).toBeGreaterThanOrEqual(1);
    expect(s.daily).toHaveLength(7);
    expect(s.daily[6].total).toBeGreaterThanOrEqual(1);
    expect(s.recentModeration.length).toBeGreaterThan(0);
    expect(s.recentModeration[0]).toMatchObject({ action: expect.any(String), user: { name: expect.any(String) } });
  });

  test("housekeeping exposes the new job", async () => {
    const queued = await api("post", "/admin/housekeeping/lift-expired-suspensions/run", { token: admin.token });
    expect(queued.status).toBe(202);
  });
});
