DROP TABLE IF EXISTS moderation_actions;
DROP INDEX IF EXISTS users_suspension_expiry_idx, users_created_idx, users_role_status_idx;
ALTER TABLE users
  DROP COLUMN IF EXISTS last_login_at,
  DROP COLUMN IF EXISTS status_changed_by,
  DROP COLUMN IF EXISTS status_changed_at,
  DROP COLUMN IF EXISTS suspended_until,
  DROP COLUMN IF EXISTS status_reason,
  DROP COLUMN IF EXISTS account_status;
DROP TYPE IF EXISTS account_status;
