-- Account moderation: suspend / ban / reinstate (applies to riders and drivers) ----------

CREATE TYPE account_status AS ENUM ('active', 'suspended', 'banned');

ALTER TABLE users
  ADD COLUMN account_status    account_status NOT NULL DEFAULT 'active',
  ADD COLUMN status_reason     TEXT,
  ADD COLUMN suspended_until   TIMESTAMPTZ,            -- NULL while suspended = indefinite
  ADD COLUMN status_changed_at TIMESTAMPTZ,
  ADD COLUMN status_changed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  ADD COLUMN last_login_at     TIMESTAMPTZ;

CREATE INDEX users_role_status_idx ON users (role, account_status);
CREATE INDEX users_created_idx     ON users (created_at DESC);
CREATE INDEX users_suspension_expiry_idx ON users (suspended_until)
  WHERE account_status = 'suspended' AND suspended_until IS NOT NULL;

-- Append-only audit trail of every moderation decision.
CREATE TABLE moderation_actions (
  id              BIGSERIAL PRIMARY KEY,
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  admin_id        UUID REFERENCES users(id) ON DELETE SET NULL,   -- NULL = automatic (expiry)
  action          TEXT NOT NULL CHECK (action IN ('suspend', 'ban', 'reinstate', 'auto_reinstate')),
  previous_status account_status NOT NULL,
  new_status      account_status NOT NULL,
  reason          TEXT,
  until           TIMESTAMPTZ,
  data            JSONB NOT NULL DEFAULT '{}',                     -- e.g. affected rides
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX moderation_actions_user_idx    ON moderation_actions (user_id, id DESC);
CREATE INDEX moderation_actions_created_idx ON moderation_actions (created_at DESC);
