import { pool, query, queryOne, withTransaction } from "../../db/pool.ts";
import { AppError, badRequest, conflict, forbidden, notFound } from "../../lib/errors.ts";
import { logger } from "../../lib/logger.ts";
import { cancelOfferTimeout, enqueueMatch } from "../../queues/index.ts";
import { logoutAll } from "../auth/auth.service.ts";
import { removeFromPool } from "../drivers/drivers.service.ts";
import { logEvent, releaseDriver, type RideRow } from "../rides/rides.service.ts";
import type { AccountStatus } from "./access.ts";

export type ModerationAction = "suspend" | "ban" | "reinstate";

export interface ModerationInput {
  /** Required for suspend/ban; optional note for reinstate. */
  reason?: string | undefined;
  /** Suspend only: when the suspension ends. Omit for an indefinite suspension. */
  until?: Date | undefined;
  /** Cancel a trip that is already in progress instead of refusing (409 RIDE_IN_PROGRESS). */
  force?: boolean | undefined;
}

export interface AffectedRide {
  rideId: string;
  outcome: "requeued" | "cancelled";
}

interface TargetRow {
  id: string;
  role: "rider" | "driver" | "admin";
  account_status: AccountStatus;
}

/** Run a post-commit side effect without failing the (already committed) moderation decision. */
async function safe(label: string, fn: () => Promise<unknown>) {
  try {
    await fn();
  } catch (err) {
    logger.error({ err, label }, "moderation side effect failed; housekeeping will reconcile");
  }
}

/**
 * Suspend, ban or reinstate a rider/driver.
 *
 * Everything that must be consistent happens in ONE transaction: the status change, the audit row,
 * live-ride handling, pending offers and the driver's availability. Valkey / queue side effects
 * (geo index, session revocation, re-matching) run right after the commit.
 *
 * Live rides:
 *  - Rider moderated  -> their searching/accepted/arrived rides are cancelled by the system, the driver is freed.
 *  - Driver moderated -> accepted/arrived rides go back to `searching` (re-matched with someone else).
 *  - A trip already `in_progress` is never abandoned silently: 409 RIDE_IN_PROGRESS unless `force` is set,
 *    in which case it is cancelled by the system.
 */
export async function moderate(adminId: string, targetId: string, action: ModerationAction, input: ModerationInput) {
  if (adminId === targetId) throw badRequest("You cannot moderate your own account");

  const after = {
    banned: false,
    poolRemoval: null as null | { userId: string; type: any },
    releaseDrivers: new Set<string>(),
    rematch: new Set<string>(),
    cancelTimeouts: [] as string[],
  };
  const affected: AffectedRide[] = [];

  const account = await withTransaction(async (tx) => {
    const target = await queryOne<TargetRow>("SELECT id, role, account_status FROM users WHERE id = $1 FOR UPDATE", [targetId], tx);
    if (!target) throw notFound("User not found");
    if (target.role === "admin") throw forbidden("Admin accounts cannot be moderated");

    const prev = target.account_status;
    if (action === "ban" && prev === "banned") throw conflict("Account is already banned", "INVALID_STATE");
    if (action === "suspend" && prev === "banned") throw conflict("Banned accounts must be reinstated before they can be suspended", "INVALID_STATE");
    if (action === "reinstate" && prev === "active") throw conflict("Account is already active", "INVALID_STATE");
    if (action === "suspend" && input.until && input.until.getTime() <= Date.now()) throw badRequest("`until` must be in the future");

    const newStatus: AccountStatus = action === "suspend" ? "suspended" : action === "ban" ? "banned" : "active";
    const reason = input.reason?.trim() || null;

    if (action !== "reinstate") {
      // 1) live rides involving this user
      const rides = await query<RideRow>(
        `SELECT * FROM rides WHERE (rider_id = $1 OR driver_id = $1)
            AND status IN ('searching','accepted','arrived','in_progress') FOR UPDATE`,
        [targetId],
        tx,
      );
      const inProgress = rides.find((r) => r.status === "in_progress");
      if (inProgress && !input.force) {
        throw new AppError(
          409,
          "RIDE_IN_PROGRESS",
          "This account has a trip in progress. Wait for it to finish, or retry with force=true to cancel it.",
          { rideId: inProgress.id },
        );
      }

      const cancelReason = `Account ${newStatus} by administrator`;
      for (const r of rides) {
        const driverIsTarget = r.driver_id === targetId;
        if (driverIsTarget && (r.status === "accepted" || r.status === "arrived")) {
          await query(
            "UPDATE rides SET status='searching', driver_id=NULL, accepted_at=NULL, arrived_at=NULL, updated_at=now() WHERE id=$1",
            [r.id],
            tx,
          );
          await logEvent(tx, r.id, "driver_removed", adminId, { moderation: action });
          after.rematch.add(r.id);
          affected.push({ rideId: r.id, outcome: "requeued" });
        } else {
          await query(
            `UPDATE rides SET status='cancelled', cancelled_by='system', cancel_reason=$2, cancelled_at=now(), updated_at=now() WHERE id=$1`,
            [r.id, cancelReason],
            tx,
          );
          await query("UPDATE ride_offers SET status='cancelled', responded_at=now() WHERE ride_id=$1 AND status='pending'", [r.id], tx);
          await logEvent(tx, r.id, "cancelled", adminId, { by: "system", reason: cancelReason, moderation: action });
          if (r.driver_id && !driverIsTarget) after.releaseDrivers.add(r.driver_id);
          affected.push({ rideId: r.id, outcome: "cancelled" });
        }
      }

      // 2) a driver: withdraw pending offers (their rides must be offered to someone else) and force offline
      if (target.role === "driver") {
        const offers = await query<{ id: string; ride_id: string }>(
          "UPDATE ride_offers SET status='cancelled', responded_at=now() WHERE driver_id=$1 AND status='pending' RETURNING id, ride_id",
          [targetId],
          tx,
        );
        for (const o of offers) {
          after.rematch.add(o.ride_id);
          after.cancelTimeouts.push(o.id);
        }
        const d = await queryOne<{ vehicle_type: string }>(
          "UPDATE drivers SET status='offline', updated_at=now() WHERE user_id=$1 RETURNING vehicle_type",
          [targetId],
          tx,
        );
        if (d) after.poolRemoval = { userId: targetId, type: d.vehicle_type };
      }
      if (action === "ban") after.banned = true;
    }

    // 3) the decision itself + audit row
    const until = action === "suspend" ? (input.until ?? null) : null;
    const row = (
      await query<{ account_status: AccountStatus; status_reason: string | null; suspended_until: Date | null; status_changed_at: Date }>(
        `UPDATE users SET account_status = $2, status_reason = $3, suspended_until = $4,
                          status_changed_at = now(), status_changed_by = $5, updated_at = now()
          WHERE id = $1 RETURNING account_status, status_reason, suspended_until, status_changed_at`,
        [targetId, newStatus, action === "reinstate" ? null : reason, until, adminId],
        tx,
      )
    )[0]!;
    await query(
      `INSERT INTO moderation_actions (user_id, admin_id, action, previous_status, new_status, reason, until, data)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [targetId, adminId, action, prev, newStatus, reason, until, JSON.stringify({ affectedRides: affected })],
      tx,
    );
    return { status: row.account_status, reason: row.status_reason, until: row.suspended_until, changedAt: row.status_changed_at };
  });

  // Post-commit side effects (idempotent / reconciled by housekeeping if they fail)
  if (after.banned) await safe("revoke-sessions", () => logoutAll(targetId)); // access tokens die immediately too
  if (after.poolRemoval) await safe("geo-remove", () => removeFromPool(after.poolRemoval!.userId, after.poolRemoval!.type));
  for (const id of after.cancelTimeouts) await safe("cancel-offer-timeout", () => cancelOfferTimeout(id));
  for (const id of after.releaseDrivers) await safe("release-driver", () => releaseDriver(id));
  for (const id of after.rematch) await safe("rematch", () => enqueueMatch(id));

  return { account, affectedRides: affected };
}

/** Housekeeping: persistently lift every suspension whose end date has passed. Returns how many. */
export async function liftExpiredSuspensions(): Promise<number> {
  const rows = await query(
    `WITH lifted AS (
       UPDATE users SET account_status = 'active', status_reason = NULL, suspended_until = NULL,
                        status_changed_at = now(), status_changed_by = NULL
        WHERE account_status = 'suspended' AND suspended_until IS NOT NULL AND suspended_until <= now()
        RETURNING id)
     INSERT INTO moderation_actions (user_id, admin_id, action, previous_status, new_status, reason)
     SELECT id, NULL, 'auto_reinstate', 'suspended', 'active', 'Suspension expired' FROM lifted RETURNING 1`,
    [],
    pool,
  );
  return rows.length;
}
