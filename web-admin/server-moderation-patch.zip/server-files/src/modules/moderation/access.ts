/**
 * Lightweight account-standing checks used on hot paths (go online, accept offer, request ride, ...).
 * Deliberately depends only on the DB helpers so driver/ride services can import it without cycles.
 */
import { pool, queryOne, type Queryable } from "../../db/pool.ts";
import { AppError, unauthorized } from "../../lib/errors.ts";

export type AccountStatus = "active" | "suspended" | "banned";

interface StandingRow {
  account_status: AccountStatus;
  status_reason: string | null;
  suspended_until: Date | null;
}

/** Lift one user's suspension if its end date has passed (the housekeeping job does this in bulk). */
export async function liftSuspensionIfExpired(userId: string, db: Queryable = pool): Promise<boolean> {
  const row = await queryOne(
    `WITH lifted AS (
       UPDATE users SET account_status = 'active', status_reason = NULL, suspended_until = NULL,
                        status_changed_at = now(), status_changed_by = NULL
        WHERE id = $1 AND account_status = 'suspended' AND suspended_until IS NOT NULL AND suspended_until <= now()
        RETURNING id)
     INSERT INTO moderation_actions (user_id, admin_id, action, previous_status, new_status, reason)
     SELECT id, NULL, 'auto_reinstate', 'suspended', 'active', 'Suspension expired' FROM lifted RETURNING 1`,
    [userId],
    db,
  );
  return !!row;
}

/**
 * Throws 403 ACCOUNT_BANNED / ACCOUNT_SUSPENDED (with `details: {reason, until}`) unless the account is in good standing.
 * A suspension whose end date has passed is lifted on the spot.
 */
export async function assertCanOperate(userId: string): Promise<void> {
  const row = await queryOne<StandingRow>("SELECT account_status, status_reason, suspended_until FROM users WHERE id = $1", [userId]);
  if (!row) throw unauthorized("Account not found");
  if (row.account_status === "active") return;

  if (row.account_status === "suspended" && row.suspended_until && row.suspended_until.getTime() <= Date.now()) {
    await liftSuspensionIfExpired(userId);
    return;
  }
  if (row.account_status === "banned") {
    throw new AppError(403, "ACCOUNT_BANNED", "Your account has been banned", { reason: row.status_reason });
  }
  throw new AppError(
    403,
    "ACCOUNT_SUSPENDED",
    row.suspended_until ? `Your account is suspended until ${row.suspended_until.toISOString()}` : "Your account is suspended",
    { reason: row.status_reason, until: row.suspended_until },
  );
}
