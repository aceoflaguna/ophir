import { Router } from "express";
import { z } from "zod";
import { ah } from "../../lib/async-handler.ts";
import { authenticate, requireRole } from "../../middleware/auth.ts";
import { validate } from "../../middleware/validate.ts";
import { moderate } from "../moderation/moderation.service.ts";
import * as admin from "./admin.service.ts";

/**
 * Admin web-app API: dashboard, rider/driver directory + detail, ride directory + detail, and moderation.
 * Mounted at /api/v1/admin next to the existing housekeeping admin router.
 */
export const adminUsersRouter = Router();
adminUsersRouter.use(authenticate, requireRole("admin"));

const idParam = z.object({ id: z.string().uuid() });
const paging = {
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
};
const q = z.string().trim().max(100).optional();

adminUsersRouter.get("/stats", ah(async (_req, res) => {
  res.json(await admin.dashboard());
}));

/* ------------------------------------------------------------------ users */

const listUsersSchema = z.object({
  role: z.enum(["rider", "driver"]).optional(),
  status: z.enum(["active", "suspended", "banned"]).optional(),
  driverStatus: z.enum(["online", "offline", "busy"]).optional(),
  q,
  sort: z.enum(["newest", "oldest", "name", "rating", "rides", "lastLogin"]).default("newest"),
  ...paging,
});
adminUsersRouter.get("/users", validate(listUsersSchema, "query"), ah(async (req, res) => {
  res.json(await admin.listUsers(req.query as unknown as z.infer<typeof listUsersSchema>));
}));

adminUsersRouter.get("/users/:id", validate(idParam, "params"), ah(async (req, res) => {
  res.json(await admin.userDetail(req.params.id!));
}));

const userRidesSchema = z.object({ status: z.string().max(20).optional(), ...paging });
adminUsersRouter.get("/users/:id/rides", validate(idParam, "params"), validate(userRidesSchema, "query"), ah(async (req, res) => {
  const qy = req.query as unknown as z.infer<typeof userRidesSchema>;
  res.json(await admin.listRides({ userId: req.params.id!, status: qy.status, limit: qy.limit, offset: qy.offset }));
}));

/* ------------------------------------------------------------- moderation */

const reason = z.string().trim().min(3, "Please give a reason (min 3 characters)").max(500);
const force = z.boolean().default(false);

const suspendSchema = z.object({
  reason,
  /** ISO 8601 end date; omit/null for an indefinite suspension */
  until: z.string().datetime({ offset: true }).nullish().transform((v) => (v ? new Date(v) : undefined)),
  force,
});
adminUsersRouter.post("/users/:id/suspend", validate(idParam, "params"), validate(suspendSchema), ah(async (req, res) => {
  res.json(await moderate(req.auth!.userId, req.params.id!, "suspend", req.body));
}));

adminUsersRouter.post("/users/:id/ban", validate(idParam, "params"), validate(z.object({ reason, force })), ah(async (req, res) => {
  res.json(await moderate(req.auth!.userId, req.params.id!, "ban", req.body));
}));

adminUsersRouter.post("/users/:id/reinstate", validate(idParam, "params"), validate(z.object({ note: z.string().trim().max(500).optional() })), ah(async (req, res) => {
  res.json(await moderate(req.auth!.userId, req.params.id!, "reinstate", { reason: req.body.note }));
}));

/* ------------------------------------------------------------------ rides */

const listRidesSchema = z.object({
  status: z.enum(["active", "searching", "accepted", "arrived", "in_progress", "completed", "cancelled", "no_drivers"]).optional(),
  userId: z.string().uuid().optional(),
  q,
  ...paging,
});
adminUsersRouter.get("/rides", validate(listRidesSchema, "query"), ah(async (req, res) => {
  res.json(await admin.listRides(req.query as unknown as z.infer<typeof listRidesSchema>));
}));

adminUsersRouter.get("/rides/:id", validate(idParam, "params"), ah(async (req, res) => {
  res.json(await admin.rideDetail(req.params.id!));
}));
