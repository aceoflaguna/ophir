/**
 * Read models for the admin web app: dashboard numbers, user (rider/driver) search + detail, ride search + detail.
 * Plain parameterised SQL; optional filters use the `($n IS NULL OR ...)` pattern so each query has one fixed shape.
 */
import { env } from "../../config/env.ts";
import { query, queryOne } from "../../db/pool.ts";
import { notFound } from "../../lib/errors.ts";
import { readLocation } from "../drivers/drivers.service.ts";
import type { AccountStatus } from "../moderation/access.ts";
import { toRide, type RideRow } from "../rides/rides.service.ts";

const escapeLike = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);
const likeParam = (q?: string) => (q?.trim() ? `%${escapeLike(q.trim())}%` : null);
const LIVE = ["searching", "accepted", "arrived", "in_progress"];

/* ------------------------------------------------------------------ users */

export interface ListUsersOpts {
  role?: "rider" | "driver" | undefined;
  status?: AccountStatus | undefined;
  driverStatus?: "online" | "offline" | "busy" | undefined;
  q?: string | undefined;
  sort: "newest" | "oldest" | "name" | "rating" | "rides" | "lastLogin";
  limit: number;
  offset: number;
}

const USER_ORDER: Record<ListUsersOpts["sort"], string> = {
  newest: "u.created_at DESC",
  oldest: "u.created_at ASC",
  name: "lower(u.full_name) ASC",
  rating: "u.rating_avg DESC, u.rating_count DESC",
  rides: "rides_total DESC",
  lastLogin: "u.last_login_at DESC NULLS LAST",
};

const USER_WHERE = `
  u.role <> 'admin'
  AND ($1::user_role IS NULL OR u.role = $1)
  AND ($2::account_status IS NULL OR u.account_status = $2)
  AND ($3::driver_status IS NULL OR d.status = $3)
  AND ($4::text IS NULL OR u.email ILIKE $4 OR u.full_name ILIKE $4 OR u.phone ILIKE $4 OR d.plate_number ILIKE $4 OR u.id::text = $5)`;

const mapUserRow = (r: any) => ({
  id: r.id as string,
  email: r.email as string,
  phone: r.phone as string | null,
  fullName: r.full_name as string,
  role: r.role as "rider" | "driver",
  rating: { average: r.rating_avg as number, count: r.rating_count as number },
  isActive: r.is_active as boolean,
  createdAt: r.created_at as Date,
  lastLoginAt: r.last_login_at as Date | null,
  account: { status: r.account_status as AccountStatus, reason: r.status_reason as string | null, until: r.suspended_until as Date | null },
  ridesTotal: r.rides_total as number,
  driver:
    r.driver_status == null
      ? null
      : {
          status: r.driver_status as string,
          vehicle: { make: r.vehicle_make, model: r.vehicle_model, color: r.vehicle_color, plate: r.plate_number, type: r.vehicle_type },
          location: r.last_lat == null ? null : { lat: r.last_lat as number, lng: r.last_lng as number, lastSeenAt: r.last_seen_at as Date | null },
          totalEarnings: r.total_earnings as number,
        },
});

export async function listUsers(o: ListUsersOpts) {
  const like = likeParam(o.q);
  const filters = [o.role ?? null, o.status ?? null, o.driverStatus ?? null, like, o.q?.trim().toLowerCase() ?? null];
  const [rows, count] = await Promise.all([
    query(
      `SELECT u.id, u.email, u.phone, u.full_name, u.role, u.rating_avg, u.rating_count, u.is_active,
              u.account_status, u.status_reason, u.suspended_until, u.created_at, u.last_login_at,
              d.status AS driver_status, d.vehicle_make, d.vehicle_model, d.vehicle_color, d.plate_number, d.vehicle_type,
              d.last_lat, d.last_lng, d.last_seen_at, d.total_earnings,
              (SELECT count(*) FROM rides r WHERE r.rider_id = u.id OR r.driver_id = u.id)::int AS rides_total
         FROM users u LEFT JOIN drivers d ON d.user_id = u.id
        WHERE ${USER_WHERE}
        ORDER BY ${USER_ORDER[o.sort]}, u.id
        LIMIT $6 OFFSET $7`,
      [...filters, o.limit, o.offset],
    ),
    queryOne<{ n: number }>(`SELECT count(*)::int AS n FROM users u LEFT JOIN drivers d ON d.user_id = u.id WHERE ${USER_WHERE}`, filters),
  ]);
  return { items: rows.map(mapUserRow), total: count?.n ?? 0, limit: o.limit, offset: o.offset };
}

export async function userDetail(id: string) {
  const u = await queryOne<any>(
    `SELECT u.*, cb.full_name AS changed_by_name FROM users u LEFT JOIN users cb ON cb.id = u.status_changed_by WHERE u.id = $1`,
    [id],
  );
  if (!u || u.role === "admin") throw notFound("User not found");

  const [driver, stats, offerStats, sessions, live, recent, history, live_loc] = await Promise.all([
    queryOne<any>("SELECT * FROM drivers WHERE user_id = $1", [id]),
    queryOne<any>(
      `SELECT count(*)::int AS total,
              count(*) FILTER (WHERE status = 'completed')::int AS completed,
              count(*) FILTER (WHERE status = 'cancelled')::int AS cancelled,
              count(*) FILTER (WHERE status = 'no_drivers')::int AS no_drivers,
              count(*) FILTER (WHERE status = ANY($2::ride_status[]))::int AS active,
              count(*) FILTER (WHERE status = 'cancelled' AND cancelled_by = 'rider' AND rider_id = $1)::int AS cancelled_by_rider,
              COALESCE(sum(final_fare) FILTER (WHERE status = 'completed'), 0) AS gross,
              COALESCE(sum(driver_earnings) FILTER (WHERE status = 'completed' AND driver_id = $1), 0) AS earnings,
              COALESCE(sum(platform_fee) FILTER (WHERE status = 'completed'), 0) AS platform_fees,
              max(requested_at) AS last_ride_at,
              (SELECT count(*) FROM ride_events e WHERE e.actor_id = $1 AND e.type = 'driver_cancelled')::int AS cancelled_by_driver
         FROM rides WHERE rider_id = $1 OR driver_id = $1`,
      [id, LIVE],
    ),
    queryOne<any>(
      `SELECT count(*)::int AS total,
              count(*) FILTER (WHERE status = 'accepted')::int AS accepted,
              count(*) FILTER (WHERE status = 'declined')::int AS declined,
              count(*) FILTER (WHERE status = 'expired')::int AS expired
         FROM ride_offers WHERE driver_id = $1`,
      [id],
    ),
    queryOne<{ n: number }>(
      "SELECT count(DISTINCT family_id)::int AS n FROM refresh_tokens WHERE user_id = $1 AND revoked_at IS NULL AND expires_at > now()",
      [id],
    ),
    listRides({ userId: id, status: "active", limit: 1, offset: 0 }),
    listRides({ userId: id, limit: 10, offset: 0 }),
    query<any>(
      `SELECT m.id, m.action, m.previous_status, m.new_status, m.reason, m.until, m.data, m.created_at, m.admin_id, a.full_name AS admin_name
         FROM moderation_actions m LEFT JOIN users a ON a.id = m.admin_id
        WHERE m.user_id = $1 ORDER BY m.id DESC LIMIT 50`,
      [id],
    ),
    u.role === "driver" ? readLocation(id) : Promise.resolve(null),
  ]);

  const s = stats ?? {};
  const o = offerStats ?? {};
  return {
    user: {
      id: u.id as string,
      email: u.email as string,
      phone: u.phone as string | null,
      fullName: u.full_name as string,
      role: u.role as "rider" | "driver",
      rating: { average: u.rating_avg as number, count: u.rating_count as number },
      isActive: u.is_active as boolean,
      createdAt: u.created_at as Date,
      lastLoginAt: u.last_login_at as Date | null,
      account: {
        status: u.account_status as AccountStatus,
        reason: u.status_reason as string | null,
        until: u.suspended_until as Date | null,
        changedAt: u.status_changed_at as Date | null,
        changedBy: u.status_changed_by ? { id: u.status_changed_by as string, name: u.changed_by_name as string } : null,
      },
    },
    driver: driver
      ? {
          status: driver.status as string,
          licenseNumber: driver.license_number as string,
          vehicle: { make: driver.vehicle_make, model: driver.vehicle_model, color: driver.vehicle_color, plate: driver.plate_number, type: driver.vehicle_type },
          location:
            live_loc ?? (driver.last_lat != null ? { lat: driver.last_lat, lng: driver.last_lng, at: driver.last_seen_at ? new Date(driver.last_seen_at).getTime() : null } : null),
          totalEarnings: driver.total_earnings as number,
        }
      : null,
    stats: {
      totalRides: s.total ?? 0,
      completed: s.completed ?? 0,
      cancelled: s.cancelled ?? 0,
      noDrivers: s.no_drivers ?? 0,
      active: s.active ?? 0,
      cancelledByRider: s.cancelled_by_rider ?? 0,
      cancelledByDriver: s.cancelled_by_driver ?? 0,
      gross: s.gross ?? 0,
      earnings: s.earnings ?? 0,
      platformFees: s.platform_fees ?? 0,
      lastRideAt: (s.last_ride_at as Date | null) ?? null,
      offers: u.role === "driver" ? { total: o.total ?? 0, accepted: o.accepted ?? 0, declined: o.declined ?? 0, expired: o.expired ?? 0 } : null,
    },
    activeSessions: sessions?.n ?? 0,
    activeRide: live.items[0] ?? null,
    recentRides: recent.items,
    moderation: history.map((m) => ({
      id: m.id as number,
      action: m.action as string,
      previousStatus: m.previous_status as AccountStatus,
      newStatus: m.new_status as AccountStatus,
      reason: m.reason as string | null,
      until: m.until as Date | null,
      affectedRides: (m.data?.affectedRides ?? []) as unknown[],
      createdAt: m.created_at as Date,
      admin: m.admin_id ? { id: m.admin_id as string, name: m.admin_name as string } : null,
    })),
  };
}

/* ------------------------------------------------------------------ rides */

export interface ListRidesOpts {
  /** a ride status, or `active` for every live status */
  status?: string | undefined;
  userId?: string | undefined;
  q?: string | undefined;
  limit: number;
  offset: number;
}

const RIDE_WHERE = `
  ($1::text IS NULL OR r.status::text = $1 OR ($1 = 'active' AND r.status = ANY($2::ride_status[])))
  AND ($3::uuid IS NULL OR r.rider_id = $3 OR r.driver_id = $3)
  AND ($4::text IS NULL OR ru.full_name ILIKE $4 OR ru.email ILIKE $4 OR du.full_name ILIKE $4 OR du.email ILIKE $4
       OR r.pickup_address ILIKE $4 OR r.dropoff_address ILIKE $4 OR r.id::text = $5)`;

export async function listRides(o: ListRidesOpts) {
  const filters = [o.status ?? null, LIVE, o.userId ?? null, likeParam(o.q), o.q?.trim().toLowerCase() ?? null];
  const [rows, count] = await Promise.all([
    query<any>(
      `SELECT r.id, r.status, r.vehicle_type, r.pickup_address, r.pickup_lat, r.pickup_lng, r.dropoff_address, r.dropoff_lat, r.dropoff_lng,
              r.estimated_fare, r.final_fare, r.currency, r.payment_method, r.requested_at, r.completed_at, r.cancelled_at,
              r.cancelled_by, r.cancel_reason, r.rider_rating, r.driver_rating,
              r.rider_id, ru.full_name AS rider_name, r.driver_id, du.full_name AS driver_name
         FROM rides r JOIN users ru ON ru.id = r.rider_id LEFT JOIN users du ON du.id = r.driver_id
        WHERE ${RIDE_WHERE}
        ORDER BY r.requested_at DESC, r.id
        LIMIT $6 OFFSET $7`,
      [...filters, o.limit, o.offset],
    ),
    queryOne<{ n: number }>(
      `SELECT count(*)::int AS n FROM rides r JOIN users ru ON ru.id = r.rider_id LEFT JOIN users du ON du.id = r.driver_id WHERE ${RIDE_WHERE}`,
      filters,
    ),
  ]);
  return {
    items: rows.map((r) => ({
      id: r.id as string,
      status: r.status as string,
      vehicleType: r.vehicle_type as string,
      pickup: { address: r.pickup_address as string | null, lat: r.pickup_lat as number, lng: r.pickup_lng as number },
      dropoff: { address: r.dropoff_address as string | null, lat: r.dropoff_lat as number, lng: r.dropoff_lng as number },
      fare: (r.final_fare ?? r.estimated_fare) as number,
      isFinalFare: r.final_fare != null,
      currency: (r.currency as string).trim(),
      paymentMethod: r.payment_method as string,
      requestedAt: r.requested_at as Date,
      completedAt: r.completed_at as Date | null,
      cancelledAt: r.cancelled_at as Date | null,
      cancelledBy: r.cancelled_by as string | null,
      cancelReason: r.cancel_reason as string | null,
      ratings: { rider: r.rider_rating as number | null, driver: r.driver_rating as number | null },
      rider: { id: r.rider_id as string, name: r.rider_name as string },
      driver: r.driver_id ? { id: r.driver_id as string, name: r.driver_name as string } : null,
    })),
    total: count?.n ?? 0,
    limit: o.limit,
    offset: o.offset,
  };
}

export async function rideDetail(id: string) {
  const r = await queryOne<any>(
    `SELECT r.*, ru.full_name AS rider_name, ru.email AS rider_email, ru.phone AS rider_phone, ru.account_status AS rider_account,
            du.full_name AS driver_name, du.email AS driver_email, du.phone AS driver_phone, du.account_status AS driver_account,
            d.vehicle_make, d.vehicle_model, d.vehicle_color, d.plate_number
       FROM rides r JOIN users ru ON ru.id = r.rider_id
       LEFT JOIN users du ON du.id = r.driver_id LEFT JOIN drivers d ON d.user_id = r.driver_id
      WHERE r.id = $1`,
    [id],
  );
  if (!r) throw notFound("Ride not found");

  const [events, offers, payment] = await Promise.all([
    query<any>(
      `SELECT e.id, e.type, e.actor_id, a.full_name AS actor_name, e.data, e.created_at
         FROM ride_events e LEFT JOIN users a ON a.id = e.actor_id WHERE e.ride_id = $1 ORDER BY e.id`,
      [id],
    ),
    query<any>(
      `SELECT o.id, o.driver_id, u.full_name AS driver_name, o.status, o.distance_km, o.created_at, o.responded_at
         FROM ride_offers o JOIN users u ON u.id = o.driver_id WHERE o.ride_id = $1 ORDER BY o.created_at`,
      [id],
    ),
    queryOne<any>("SELECT amount, currency, method, status, created_at FROM payments WHERE ride_id = $1", [id]),
  ]);

  return {
    ride: toRide(r as RideRow),
    rider: { id: r.rider_id as string, name: r.rider_name as string, email: r.rider_email as string, phone: r.rider_phone as string | null, accountStatus: r.rider_account as AccountStatus },
    driver: r.driver_id
      ? {
          id: r.driver_id as string, name: r.driver_name as string, email: r.driver_email as string, phone: r.driver_phone as string | null,
          accountStatus: r.driver_account as AccountStatus,
          vehicle: { make: r.vehicle_make, model: r.vehicle_model, color: r.vehicle_color, plate: r.plate_number },
        }
      : null,
    events: events.map((e) => ({
      id: e.id as number, type: e.type as string, data: e.data as Record<string, unknown>, createdAt: e.created_at as Date,
      actor: e.actor_id ? { id: e.actor_id as string, name: e.actor_name as string } : null,
    })),
    offers: offers.map((o) => ({
      id: o.id as string, driver: { id: o.driver_id as string, name: o.driver_name as string }, status: o.status as string,
      distanceKm: o.distance_km as number | null, createdAt: o.created_at as Date, respondedAt: o.responded_at as Date | null,
    })),
    payment: payment ? { amount: payment.amount as number, currency: (payment.currency as string).trim(), method: payment.method as string, status: payment.status as string, createdAt: payment.created_at as Date } : null,
  };
}

/* -------------------------------------------------------------- dashboard */

export async function dashboard() {
  const [userRows, driverRows, rideRows, today, newUsers, daily, actions] = await Promise.all([
    query<{ role: string; account_status: AccountStatus; n: number }>(
      "SELECT role, account_status, count(*)::int AS n FROM users WHERE role <> 'admin' GROUP BY 1, 2",
    ),
    query<{ status: string; n: number }>("SELECT status, count(*)::int AS n FROM drivers GROUP BY 1"),
    query<{ status: string; n: number }>("SELECT status, count(*)::int AS n FROM rides GROUP BY 1"),
    queryOne<any>(
      `SELECT count(*)::int AS requested,
              count(*) FILTER (WHERE status = 'completed')::int AS completed,
              COALESCE(sum(final_fare) FILTER (WHERE status = 'completed'), 0) AS gross,
              COALESCE(sum(platform_fee) FILTER (WHERE status = 'completed'), 0) AS fees
         FROM rides WHERE requested_at >= date_trunc('day', now())`,
    ),
    query<{ role: string; n: number }>("SELECT role, count(*)::int AS n FROM users WHERE role <> 'admin' AND created_at >= now() - interval '7 days' GROUP BY 1"),
    query<{ day: string; total: number; completed: number }>(
      `SELECT to_char(d, 'YYYY-MM-DD') AS day, count(r.id)::int AS total, (count(r.id) FILTER (WHERE r.status = 'completed'))::int AS completed
         FROM generate_series(date_trunc('day', now()) - interval '6 days', date_trunc('day', now()), interval '1 day') d
         LEFT JOIN rides r ON r.requested_at >= d AND r.requested_at < d + interval '1 day'
        GROUP BY d ORDER BY d`,
    ),
    query<any>(
      `SELECT m.id, m.action, m.reason, m.created_at, m.user_id, u.full_name AS user_name, u.role AS user_role, a.full_name AS admin_name
         FROM moderation_actions m JOIN users u ON u.id = m.user_id LEFT JOIN users a ON a.id = m.admin_id
        ORDER BY m.id DESC LIMIT 8`,
    ),
  ]);

  const byRole = (role: string) => {
    const base = { total: 0, active: 0, suspended: 0, banned: 0 };
    for (const r of userRows) if (r.role === role) { base[r.account_status] += r.n; base.total += r.n; }
    return base;
  };
  const count = (rows: { status: string; n: number }[], s: string) => rows.find((r) => r.status === s)?.n ?? 0;

  return {
    currency: env.CURRENCY,
    riders: { ...byRole("rider"), new7d: newUsers.find((r) => r.role === "rider")?.n ?? 0 },
    drivers: {
      ...byRole("driver"),
      new7d: newUsers.find((r) => r.role === "driver")?.n ?? 0,
      online: count(driverRows, "online"),
      busy: count(driverRows, "busy"),
      offline: count(driverRows, "offline"),
    },
    rides: {
      live: LIVE.reduce((a, s) => a + count(rideRows, s), 0),
      searching: count(rideRows, "searching"),
      inProgress: count(rideRows, "in_progress"),
      completed: count(rideRows, "completed"),
      cancelled: count(rideRows, "cancelled") + count(rideRows, "no_drivers"),
      total: rideRows.reduce((a, r) => a + r.n, 0),
    },
    today: { requested: today?.requested ?? 0, completed: today?.completed ?? 0, gross: today?.gross ?? 0, platformFees: today?.fees ?? 0 },
    daily,
    recentModeration: actions.map((m) => ({
      id: m.id as number, action: m.action as string, reason: m.reason as string | null, createdAt: m.created_at as Date,
      user: { id: m.user_id as string, name: m.user_name as string, role: m.user_role as string }, admin: (m.admin_name as string | null) ?? null,
    })),
  };
}
