# Moderation patch for the Uber-clone API

Apply from the project root: `patch -p1 < server-moderation.patch` (or `git apply server-moderation.patch`).
`server-files/` holds the full final copy of every touched file if you prefer to copy them over.

1. Run the migration: `bun run migrate` (adds `0002_moderation`; `bun run migrate:down` reverts it).
2. Restart the API **and the worker** (the worker runs the new `lift-expired-suspensions` job).
3. Run the tests: `npm test` (95 tests, 20 of them new in `tests/e2e/moderation.e2e.test.ts`).

New: `src/modules/moderation/*`, `src/modules/admin/*`, migration `0002`, endpoints listed in README ("Admin: moderation").
Changed: app.ts (mounts `/admin`), auth.service (ban checks, `account` in the user payload, `last_login_at`), drivers.service and rides.service (suspension guards), matching.service (only active drivers), queues and housekeeping (new job). Postman has a new "Admin - Moderation" folder.
